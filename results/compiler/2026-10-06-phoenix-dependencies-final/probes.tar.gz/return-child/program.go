package child
import "gosvm/solana"
func Process(c solana.Context)uint64{
 d:=solana.Instruction(c);if len(d)!=1{return 7361}
 if d[0]==2{return 7351}
 if d[0]==1{var b [3]byte;b[0]=9;b[1]=8;b[2]=7;return solana.SetReturnData(c,b[:])}
 return 0
}
