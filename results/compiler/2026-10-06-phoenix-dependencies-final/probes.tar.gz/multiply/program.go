package multiply
import "gosvm/solana"
func read(b []byte, o uint64) uint64 {
 var x uint64
 for i:=uint64(0);i<8;i++ { x = x | (uint64(b[o+i]) << (8*i)) }
 return x
}
func Process(c solana.Context) uint64 {
 b:=solana.Data(c,0)
 a:=read(b,0)
 v:=read(b,8)
 if v!=0 && a>18446744073709551615/v { b[uint64(len(b))]=0 }
 product:=a*v
 for i:=uint64(0);i<8;i++ {b[16+i]=byte(product>>(8*i))}
 return 0
}
