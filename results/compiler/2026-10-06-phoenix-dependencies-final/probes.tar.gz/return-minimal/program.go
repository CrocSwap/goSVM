package returnprobe
import "gosvm/solana"
// Desired new boundary API: exact bytes after every CPI and final state update.
func Process(c solana.Context) uint64 {
 var payload [20]byte
 payload[0]=1 // Borsh Vec length=1.
 payload[4]=100 // price_in_ticks:u64 LE.
 payload[12]=1 // order_sequence_number:u64 LE.
 return solana.SetReturnData(c,payload[:])
}
