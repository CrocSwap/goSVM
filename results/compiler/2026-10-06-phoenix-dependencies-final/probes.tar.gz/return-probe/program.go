package retprobe
import "gosvm/solana"
func Process(c solana.Context)uint64{
 d:=solana.Instruction(c);if len(d)==0{return 7360};mode:=d[0]
 if mode==1{return solana.SetReturnData(c,d[1:])}
 if mode==10{return solana.SetReturnData(c,solana.Data(c,0)[1:])}
 var b [20]byte;b[0]=1;b[4]=100;b[12]=1
 code:=solana.SetReturnData(c,b[:]);if code!=0{return code}
 if mode==2{for i:=uint64(0);i<20;i++{b[i]=99};return 0}
 if mode==3{return solana.SetReturnData(c,nil)}
 solana.Data(c,0)[0]=77
 if mode==7{return 7350}
 if mode==8{return solana.Invoke(c,99,nil,nil,nil)}
 var ix [1]byte
 if mode==5{ix[0]=1};if mode==9{ix[0]=2}
 code=solana.Invoke(c,1,nil,ix[:],nil);if code!=0{return code}
 if mode==6{return solana.SetReturnData(c,b[:])}
 return 0
}
