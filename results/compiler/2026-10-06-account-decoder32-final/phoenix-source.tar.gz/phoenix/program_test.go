package phoenix

import (
	"bytes"
	"compress/gzip"
	"encoding/hex"
	"encoding/json"
	"gosvm/solana"
	"math/big"
	"math/rand"
	"os"
	"testing"
)

type oracleCase struct{ Name, Input, Output, Instruction string }

func TestPinnedRustAccounts(t *testing.T) {
	f, err := os.Open("testdata/oracle.json.gz")
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	z, err := gzip.NewReader(f)
	if err != nil {
		t.Fatal(err)
	}
	defer z.Close()
	var fixture struct {
		Discriminant uint64
		Payer        string
	}
	decoder := json.NewDecoder(z)
	token, err := decoder.Token()
	if err != nil || token != json.Delim('{') {
		t.Fatal("root", token, err)
	}
	token, err = decoder.Token()
	if err != nil || token != "discriminant" {
		t.Fatal("discriminant key")
	}
	if err = decoder.Decode(&fixture.Discriminant); err != nil {
		t.Fatal(err)
	}
	token, err = decoder.Token()
	if err != nil || token != "payer" {
		t.Fatal("payer key")
	}
	if err = decoder.Decode(&fixture.Payer); err != nil {
		t.Fatal(err)
	}
	token, err = decoder.Token()
	if err != nil || token != "cases" {
		t.Fatal("cases key")
	}
	token, err = decoder.Token()
	if err != nil || token != json.Delim('[') {
		t.Fatal("cases array")
	}
	count := 0
	if fixture.Discriminant != Discriminant {
		t.Fatal("discriminant differs")
	}
	payer, _ := hex.DecodeString(fixture.Payer)
	program := programKey()
	log := logKey()
	for decoder.More() {
		var row oracleCase
		if err = decoder.Decode(&row); err != nil {
			t.Fatal(err)
		}
		count++
		b, _ := hex.DecodeString(row.Input)
		want, _ := hex.DecodeString(row.Output)
		d, _ := hex.DecodeString(row.Instruction)
		c := solana.Context{ID: program[:], InstructionData: d, ReadClock: func(out []byte) uint64 { return 0 }, Accounts: []solana.Account{{Key: program[:]}, {Key: log[:]}, {Owner: program[:], Data: b, Writable: true}, {Key: payer, Signer: true}}}
		if code := Process(c); code != 0 {
			t.Fatalf("%s: code %d", row.Name, code)
		}
		if !bytes.Equal(b, want) {
			for i := range b {
				if b[i] != want[i] {
					t.Fatalf("%s differs at %d: got %x want %x", row.Name, i, b[i], want[i])
				}
			}
		}
		// Independent economic check: sequential checked products, then floor.
		if d[1] == 0 {
			p := read64(d, 2)
			seq := read64(d, 10)
			before, _ := hex.DecodeString(row.Input)
			body := before[576:]
			n := findOrder(body[304:304+32+64*read64(before, 16)], p, seq)
			if n != 0 {
				amount := read64(d, 18)
				lots := read64(body, 304+node(n, 64)+40)
				if amount > lots {
					amount = lots
				}
				q := new(big.Int).SetUint64(p)
				q.Mul(q, new(big.Int).SetUint64(read64(body, 264)))
				q.Mul(q, new(big.Int).SetUint64(amount))
				q.Quo(q, new(big.Int).SetUint64(read64(body, 256)))
				tradersOff := uint64(304) + 2*(32+64*read64(before, 16))
				trader := findTrader(body[tradersOff:], payer)
				o := 576 + tradersOff + node(trader, 144) + 48
				if read64(b, o+8)-read64(before, o+8) != q.Uint64() {
					t.Fatal("independent quote release", row.Name)
				}
			}
		}
	}
	t.Logf("%d full-account upstream Rust differentials", count)
}
func TestCheckedArithmeticBig(t *testing.T) {
	r := rand.New(rand.NewSource(17))
	data := []byte{0}
	max := new(big.Int).SetUint64(^uint64(0))
	for j := 0; j < 10000; j++ {
		a, b := r.Uint64(), r.Uint64()
		if j%3 == 0 {
			a >>= 40
			b >>= 40
		}
		for op := 0; op < 3; op++ {
			want := new(big.Int).SetUint64(a)
			v := new(big.Int).SetUint64(b)
			if op == 0 {
				want.Add(want, v)
			} else if op == 1 {
				want.Sub(want, v)
			} else {
				want.Mul(want, v)
			}
			overflow := want.Sign() < 0 || want.Cmp(max) > 0
			trapped := false
			var got uint64
			func() {
				defer func() {
					if recover() != nil {
						trapped = true
					}
				}()
				if op == 0 {
					got = add(a, b, data)
				} else if op == 1 {
					got = sub(a, b, data)
				} else {
					got = mul(a, b, data)
				}
			}()
			if trapped != overflow || (!trapped && got != want.Uint64()) {
				t.Fatalf("op%d %d %d: trap %v", op, a, b, trapped)
			}
		}
	}
	t.Log("30,000 math-big checked-arithmetic cases")
}

func TestKeyEquality(t *testing.T) {
	r := rand.New(rand.NewSource(91))
	count := 0
	for off := 0; off < 16; off++ {
		for n := 0; n <= 256; n++ {
			a := make([]byte, n+off+16)
			b := make([]byte, n+off+16)
			r.Read(a)
			copy(b, a)
			x, y := a[off:off+n], b[off:off+n]
			if equal(x, y) != bytes.Equal(x, y) {
				t.Fatal("equal", off, n)
			}
			count++
			for j := 0; j < n; j++ {
				y[j] ^= 1
				if equal(x, y) != bytes.Equal(x, y) {
					t.Fatal("mismatch", off, n, j)
				}
				y[j] ^= 1
				count++
			}
			if n > 0 && equal(x, y[:n-1]) {
				t.Fatal("length mismatch")
			}
			count++
		}
	}
	t.Logf("%d bytes.Equal differentials, including all 32-byte mismatch positions and unaligned views", count)
}
