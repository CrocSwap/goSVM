// Package phoenix ports the pinned v1 free-funds reduction handler.
// Events are omitted by both scoped adapters. Matching and settlement are unported.
package phoenix

import "gosvm/solana"

func Process(c solana.Context) uint64 {
	d := solana.Instruction(c)
	if len(d) == 0 || d[0] != 5 {
		return 3 << 32
	}
	if solana.Count(c) < 4 {
		abort(d)
	}
	program := programKey()
	log := logKey()
	if !equal(solana.Key(c, 0), program[:]) {
		return 7 << 32
	}
	if !equal(solana.Key(c, 1), log[:]) {
		return 3 << 32
	}
	if !equal(solana.Owner(c, 2), program[:]) {
		return 18 << 32
	}
	b := solana.Data(c, 2)
	header := b[:576]
	if read64(header, 0) != Discriminant {
		return 4 << 32
	}
	bids := read64(header, 16)
	asks := read64(header, 24)
	seats := read64(header, 32)
	if !solana.Signer(c, 3) {
		return 8 << 32
	}
	var clock [40]byte
	code := solana.Clock(c, clock[:])
	if code != 0 {
		return code
	}
	if len(d) != 26 || d[1] > 1 {
		return 15 << 32
	}
	if bids != asks || (bids != 512 && bids != 1024 && bids != 2048 && bids != 4096) || (seats != 128 && seats != bids*2+1 && seats != bids*2+129) {
		return 1 << 32
	}
	size := 304 + 2*(32+64*bids) + (32 + 144*seats)
	body := b[576 : 576+size]
	if read64(body, 272) == 0 {
		return 4
	}
	bidsOff := uint64(304)
	asksOff := bidsOff + 32 + 64*bids
	tradersOff := asksOff + 32 + 64*asks
	traders := body[tradersOff:]
	trader := findTrader(traders, solana.Key(c, 3))
	if trader == 0 {
		return 16
	}
	book := body[bidsOff:asksOff]
	if d[1] == 1 {
		book = body[asksOff:tradersOff]
	}
	price := read64(d, 2)
	seq := read64(d, 10)
	n := findOrder(book, price, seq)
	if n != 0 {
		o := node(n, 64)
		lots := read64(book, o+40)
		amount := read64(d, 18)
		if amount > lots {
			amount = lots
		}
		if read64(book, o+32) != trader {
			return 16
		}
		if amount == lots {
			remove(book, n)
		} else {
			write64(book, o+40, lots-amount)
		}
		to := node(trader, 144) + 48
		if d[1] == 0 {
			quote := mul(mul(price, read64(body, 264), body), amount, body)
			denom := read64(body, 256)
			if denom == 0 {
				abort(body)
			}
			quote = quote / denom
			write64(traders, to, sub(read64(traders, to), quote, body))
			write64(traders, to+8, add(read64(traders, to+8), quote, body))
		} else {
			write64(traders, to+16, sub(read64(traders, to+16), amount, body))
			write64(traders, to+24, add(read64(traders, to+24), amount, body))
		}
	}
	write64(header, 272, add(read64(header, 272), 1, body))
	return 0
}
