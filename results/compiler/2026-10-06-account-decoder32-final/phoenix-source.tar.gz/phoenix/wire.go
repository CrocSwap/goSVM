package phoenix

func read32(b []byte, o uint64) uint32 {
	return uint32(b[o]) | uint32(b[o+1])<<8 | uint32(b[o+2])<<16 | uint32(b[o+3])<<24
}
func read64(b []byte, o uint64) uint64 {
	return uint64(read32(b, o)) | uint64(read32(b, o+4))<<32
}
func write32(b []byte, o uint64, v uint32) {
	b[o] = byte(v)
	b[o+1] = byte(v >> 8)
	b[o+2] = byte(v >> 16)
	b[o+3] = byte(v >> 24)
}
func write64(b []byte, o, v uint64) { write32(b, o, uint32(v)); write32(b, o+4, uint32(v>>32)) }
func equal(a, b []byte) bool {
	if len(a) == 32 && len(b) == 32 {
		return read64(a, 0) == read64(b, 0) && read64(a, 8) == read64(b, 8) && read64(a, 16) == read64(b, 16) && read64(a, 24) == read64(b, 24)
	}
	if len(a) != len(b) {
		return false
	}
	for j := uint64(0); j < uint64(len(a)); j++ {
		if a[j] != b[j] {
			return false
		}
	}
	return true
}

// Deliberately trap for the upstream checked-arithmetic/index panic paths.
func abort(b []byte) { b[uint64(len(b))] = 0 }
func add(a, b uint64, data []byte) uint64 {
	if a > 18446744073709551615-b {
		abort(data)
	}
	return a + b
}
func mul(a, b uint64, data []byte) uint64 {
	if b != 0 && a > 18446744073709551615/b {
		abort(data)
	}
	return a * b
}
func sub(a, b uint64, data []byte) uint64 {
	if a < b {
		abort(data)
	}
	return a - b
}
