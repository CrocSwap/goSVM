// Exact lib-sokoban 0.3.0 zero-copy register and allocator mutations.
package phoenix

func node(i, stride uint64) uint64 { return 32 + (i-1)*stride }
func reg(b []byte, i, d uint64) uint64 {
	if i == 0 {
		return 0
	}
	return uint64(read32(b, node(i, 64)+4*d))
}
func set(b []byte, i, d, v uint64) {
	if i != 0 {
		write32(b, node(i, 64)+4*d, uint32(v))
	}
}
func childDir(b []byte, p, n uint64) uint64 {
	if reg(b, p, 0) == n {
		return 0
	}
	if reg(b, p, 1) == n {
		return 1
	}
	abort(b)
	return 0
}
func connect(b []byte, p, c, d uint64) { set(b, p, d, c); set(b, c, 2, p) }
func rotate(b []byte, p, d uint64) {
	g := reg(b, p, 2)
	s := reg(b, p, 1-d)
	c := reg(b, s, d)
	connect(b, s, p, d)
	connect(b, p, c, 1-d)
	if g != 0 {
		connect(b, g, s, childDir(b, g, p))
	} else {
		set(b, s, 2, 0)
		write32(b, 0, uint32(s))
	}
}
func transplant(b []byte, n, s uint64) {
	p := reg(b, n, 2)
	if p == 0 {
		write32(b, 0, uint32(s))
		set(b, s, 2, 0)
	} else {
		connect(b, p, s, childDir(b, p, n))
	}
}
func fixRemove(b []byte, n, p, d uint64, explicit bool) {
	if !explicit {
		p = reg(b, n, 2)
		d = childDir(b, p, n)
	}
	for {
		s := reg(b, p, 1-d)
		if reg(b, s, 3) == 1 {
			set(b, s, 3, 0)
			set(b, p, 3, 1)
			rotate(b, p, d)
			s = reg(b, p, 1-d)
		}
		if reg(b, reg(b, s, 0), 3) == 0 && reg(b, reg(b, s, 1), 3) == 0 {
			set(b, s, 3, 1)
			n = p
		} else {
			if reg(b, reg(b, s, 1-d), 3) == 0 {
				set(b, reg(b, s, d), 3, 0)
				set(b, s, 3, 1)
				rotate(b, s, 1-d)
				s = reg(b, p, 1-d)
			}
			set(b, s, 3, reg(b, p, 3))
			set(b, p, 3, 0)
			set(b, reg(b, s, 1-d), 3, 0)
			rotate(b, p, d)
			n = uint64(read32(b, 0))
		}
		if n == uint64(read32(b, 0)) || reg(b, n, 3) == 1 {
			break
		}
		p = reg(b, n, 2)
		d = childDir(b, p, n)
	}
	set(b, n, 3, 0)
}
func remove(b []byte, n uint64) {
	black := reg(b, n, 3) == 0
	left := reg(b, n, 0)
	right := reg(b, n, 1)
	pivot := uint64(0)
	parent := uint64(0)
	dir := uint64(0)
	explicit := false
	if left == 0 && right == 0 {
		if n != uint64(read32(b, 0)) {
			parent = reg(b, n, 2)
			dir = childDir(b, parent, n)
			explicit = true
			connect(b, parent, 0, dir)
		} else {
			write32(b, 0, 0)
		}
	} else if left == 0 {
		transplant(b, n, right)
		pivot = right
	} else if right == 0 {
		transplant(b, n, left)
		pivot = left
	} else {
		m := left
		for reg(b, m, 1) != 0 {
			m = reg(b, m, 1)
		}
		mp := reg(b, m, 2)
		mc := reg(b, m, 0)
		black = reg(b, m, 3) == 0
		if mp != n {
			transplant(b, m, mc)
			connect(b, m, reg(b, n, 0), 0)
			if mc == 0 {
				parent = mp
				dir = 1
				explicit = true
			}
		} else if mc == 0 {
			parent = m
			dir = 0
			explicit = true
		}
		transplant(b, n, m)
		connect(b, m, reg(b, n, 1), 1)
		set(b, m, 3, reg(b, n, 3))
		pivot = mc
	}
	// Deallocate the original node, preserving its key/value payload.
	set(b, n, 2, 0)
	set(b, n, 3, 0)
	set(b, n, 0, 0)
	set(b, n, 1, 0)
	set(b, n, 0, uint64(read32(b, 28)))
	write32(b, 28, uint32(n))
	write64(b, 16, sub(read64(b, 16), 1, b))
	if black {
		if pivot == uint64(read32(b, 0)) {
			set(b, pivot, 3, 0)
		} else {
			fixRemove(b, pivot, parent, dir, explicit)
		}
	}
}
func orderCmp(price, seq, p, s uint64) uint64 {
	bid := seq>>63 != 0
	if price != p {
		if (price < p && !bid) || (price > p && bid) {
			return 1
		}
		return 2
	}
	if seq == s {
		return 0
	}
	if (seq < s && !bid) || (seq > s && bid) {
		return 1
	}
	return 2
}
func findOrder(b []byte, price, seq uint64) uint64 {
	n := uint64(read32(b, 0))
	for n != 0 {
		o := node(n, 64)
		c := orderCmp(price, seq, read64(b, o+16), read64(b, o+24))
		if c == 0 {
			return n
		}
		n = reg(b, n, c-1)
	}
	return 0
}
func findTrader(b, key []byte) uint64 {
	n := uint64(read32(b, 0))
	for n != 0 {
		o := node(n, 144)
		c := uint64(0)
		for j := uint64(0); j < 32; j++ {
			if key[j] < b[o+16+j] {
				c = 1
				break
			}
			if key[j] > b[o+16+j] {
				c = 2
				break
			}
		}
		if c == 0 {
			return n
		}
		n = uint64(read32(b, o+4*(c-1)))
	}
	return 0
}
