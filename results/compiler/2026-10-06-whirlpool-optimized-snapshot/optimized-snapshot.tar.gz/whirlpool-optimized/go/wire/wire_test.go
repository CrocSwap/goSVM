package wire

import (
	"crypto/sha256"
	"encoding/binary"
	"example.org/gosvm-benchmarks/whirlpool/math"
	"testing"
)

func TestLastTickAndSignedBytes(t *testing.T) {
	data := make([]byte, 9988)
	discriminator := sha256.Sum256([]byte("account:TickArray"))
	copy(data[:8], discriminator[:8])
	pool := Key{1, 2, 3}
	copy(data[9956:], pool[:])
	binary.LittleEndian.PutUint32(data[8:], 0xffffffa8) // -88
	if code := CheckTickArray(data, pool); code != 0 {
		t.Fatal(code)
	}
	tick := Tick{Initialized: 1, Net: math.Neg128(math.U128{Lo: 17}), Gross: math.U128{Lo: 41}, Reward2: math.U128{Lo: 19, Hi: 23}}
	if code := WriteTick(data, 87, tick); code != 0 {
		t.Fatal(code)
	}
	read, code := ReadTick(data, 87)
	if code != 0 || read != tick {
		t.Fatal(read, code)
	}
	o := 12 + 87*113
	if binary.LittleEndian.Uint64(data[o+1:]) != uint64(18446744073709551599) || binary.LittleEndian.Uint64(data[o+9:]) != ^uint64(0) {
		t.Fatal("signed i128 bytes")
	}
	if binary.LittleEndian.Uint64(data[o+97:]) != 19 || binary.LittleEndian.Uint64(data[o+105:]) != 23 {
		t.Fatal("last reward")
	}
	if Read32(data, 8) != 0xffffffa8 || ReadKey(data, 9956) != pool {
		t.Fatal("write damaged array metadata")
	}
	if _, code := ReadTick(data, 88); code != 6009 {
		t.Fatal(code)
	}
	if code := CheckTickArray(data[:9987], pool); code != ErrLayout {
		t.Fatal(code)
	}
}
