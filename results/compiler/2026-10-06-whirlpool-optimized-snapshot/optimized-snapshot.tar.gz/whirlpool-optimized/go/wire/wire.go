// Package wire accesses Orca accounts in place, without owned tick-array copies.
package wire

import "example.org/gosvm-benchmarks/whirlpool/math"

const PoolSize uint64 = 653
const TickArraySize uint64 = 9988
const TickSize uint64 = 113
const ErrLayout uint64 = 7000

type Key [32]byte
type Tick struct {
	Initialized byte
	Net         math.U128
	Gross       math.U128
	FeeA        math.U128
	FeeB        math.U128
	Reward0     math.U128
	Reward1     math.U128
	Reward2     math.U128
}

func Read64(b []byte, o uint64) uint64 {
	v := uint64(0)
	for j := uint64(0); j < 8; j++ {
		v = v | uint64(b[o+j])<<(8*j)
	}
	return v
}
func Read32(b []byte, o uint64) uint32 {
	v := uint32(0)
	for j := uint64(0); j < 4; j++ {
		v = v | uint32(b[o+j])<<(8*j)
	}
	return v
}
func Read16(b []byte, o uint64) uint32     { return uint32(b[o]) | uint32(b[o+1])<<8 }
func Read128(b []byte, o uint64) math.U128 { return math.U128{Lo: Read64(b, o), Hi: Read64(b, o+8)} }
func ReadKey(b []byte, o uint64) Key {
	var k Key
	for j := uint64(0); j < 32; j++ {
		k[j] = b[o+j]
	}
	return k
}
func Write64(b []byte, o, v uint64) {
	for j := uint64(0); j < 8; j++ {
		b[o+j] = byte(v >> (8 * j))
	}
}
func Write32(b []byte, o uint64, v uint32) {
	for j := uint64(0); j < 4; j++ {
		b[o+j] = byte(v >> (8 * j))
	}
}
func Write128(b []byte, o uint64, v math.U128) { Write64(b, o, v.Lo); Write64(b, o+8, v.Hi) }
func WriteKey(b []byte, o uint64, k Key) {
	for j := uint64(0); j < 32; j++ {
		b[o+j] = k[j]
	}
}

// The discriminator is sha256("account:TickArray")[:8], not a goSVM default.
func CheckTickArray(b []byte, pool Key) uint64 {
	if uint64(len(b)) != TickArraySize {
		return ErrLayout
	}
	if b[0] != 69 || b[1] != 97 || b[2] != 189 || b[3] != 190 || b[4] != 110 || b[5] != 7 || b[6] != 66 || b[7] != 187 {
		return ErrLayout
	}
	if ReadKey(b, 9956) != pool {
		return 6056
	}
	for i := uint64(0); i < 88; i++ {
		if b[12+i*TickSize] > 1 {
			return ErrLayout
		}
	}
	return 0
}
func ReadTick(b []byte, offset uint64) (Tick, uint64) {
	var t Tick
	if uint64(len(b)) != TickArraySize || offset >= 88 {
		return t, 6009
	}
	o := 12 + offset*TickSize
	t.Initialized = b[o]
	if t.Initialized > 1 {
		return t, ErrLayout
	}
	t.Net = Read128(b, o+1)
	t.Gross = Read128(b, o+17)
	t.FeeA = Read128(b, o+33)
	t.FeeB = Read128(b, o+49)
	t.Reward0 = Read128(b, o+65)
	t.Reward1 = Read128(b, o+81)
	t.Reward2 = Read128(b, o+97)
	return t, 0
}
func WriteTick(b []byte, offset uint64, t Tick) uint64 {
	if uint64(len(b)) != TickArraySize || offset >= 88 || t.Initialized > 1 {
		return ErrLayout
	}
	o := 12 + offset*TickSize
	b[o] = t.Initialized
	Write128(b, o+1, t.Net)
	Write128(b, o+17, t.Gross)
	Write128(b, o+33, t.FeeA)
	Write128(b, o+49, t.FeeB)
	Write128(b, o+65, t.Reward0)
	Write128(b, o+81, t.Reward1)
	Write128(b, o+97, t.Reward2)
	return 0
}
