// Package probe exposes the shared math/swap core for actual-SBF verification.
// This is a test adapter, not the Whirlpools token-transfer instruction.
package probe

import (
	"example.org/gosvm-benchmarks/whirlpool/math"
	"example.org/gosvm-benchmarks/whirlpool/swap"
	"example.org/gosvm-benchmarks/whirlpool/wire"
	"gosvm/solana"
)

func Process(c solana.Context) uint64 {
	data := solana.Instruction(c)
	if uint64(len(data)) == 0 {
		return 7100
	}
	if data[0] == 0 {
		if uint64(len(data)) != 63 || solana.Count(c) != 1 || !solana.Writable(c, 0) {
			return 7100
		}
		output := solana.Data(c, 0)
		if uint64(len(output)) != 40 {
			return 7100
		}
		result, code := math.ComputeSwap(wire.Read64(data, 1), wire.Read32(data, 9), wire.Read128(data, 13), wire.Read128(data, 29), wire.Read128(data, 45), data[61] == 1, data[62] == 1)
		if code != 0 {
			return code
		}
		wire.Write64(output, 0, result.AmountIn)
		wire.Write64(output, 8, result.AmountOut)
		wire.Write128(output, 16, result.NextPrice)
		wire.Write64(output, 32, result.Fee)
		return 0
	}
	if data[0] == 1 {
		// opcode + the exact 42-byte Orca swap instruction + test timestamp.
		if uint64(len(data)) != 51 || solana.Count(c) != 5 {
			return 7100
		}
		for j := uint64(0); j < 5; j++ {
			if !solana.Writable(c, j) {
				return 7100
			}
		}
		if data[41] > 1 || data[42] > 1 {
			return 7100
		}
		// sha256("global:swap")[:8]
		if data[1] != 248 || data[2] != 198 || data[3] != 158 || data[4] != 145 || data[5] != 225 || data[6] != 117 || data[7] != 135 || data[8] != 200 {
			return 7100
		}
		args := swap.Args{Amount: wire.Read64(data, 9), Threshold: wire.Read64(data, 17), Limit: wire.Read128(data, 25), Input: data[41] == 1, AToB: data[42] == 1}
		out := solana.Data(c, 4)
		if uint64(len(out)) != 40 {
			return 7100
		}
		key := wire.ReadKey(solana.Key(c, 0), 0)
		result, code := swap.Apply(solana.Data(c, 0), solana.Data(c, 1), solana.Data(c, 2), solana.Data(c, 3), key, args, wire.Read64(data, 43))
		if code != 0 {
			return code
		}
		wire.Write64(out, 0, result.AmountA)
		wire.Write64(out, 8, result.AmountB)
		wire.Write64(out, 16, result.LPFee)
		wire.Write64(out, 24, result.ProtocolFee)
		// Reserve the same zero word in both language test adapters.
		wire.Write64(out, 32, 0)
		return 0
	}
	return 7100
}
