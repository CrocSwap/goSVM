// Package swap ports the fixed-fee swap manager over Orca's serialized accounts.
// It excludes adaptive-fee and dynamic-tick-array pools. Transaction rollback is
// supplied by the SVM; native callers must restore buffers after an error.
package swap

import (
	"example.org/gosvm-benchmarks/whirlpool/math"
	"example.org/gosvm-benchmarks/whirlpool/wire"
)

type Args struct {
	Amount    uint64
	Threshold uint64
	Limit     math.U128
	Input     bool
	AToB      bool
}
type Result struct {
	AmountA     uint64
	AmountB     uint64
	LPFee       uint64
	ProtocolFee uint64
	Crossings   uint64
}

const ErrUnsupported uint64 = 7001

func Array(a0, a1, a2 []byte, index uint64) []byte {
	if index == 0 {
		return a0
	}
	if index == 1 {
		return a1
	}
	return a2
}
func FloorOffset(diff, spacing uint32) uint32 {
	if diff>>31 == 0 {
		return diff / spacing
	}
	return 0 - ((0 - diff + spacing - 1) / spacing)
}
func NextTick(a0, a1, a2 []byte, tick, spacing uint32, left bool, index uint64) (uint64, uint32, uint64) {
	search := tick
	for index < 3 {
		data := Array(a0, a1, a2, index)
		start := wire.Read32(data, 8)
		lower, upper := start, start+88*spacing
		if !left {
			lower = lower - spacing
			upper = upper - spacing
		}
		if math.TickLess(search, lower) || !math.TickLess(search, upper) {
			return 0, 0, 6023
		}
		offset := FloorOffset(search-start, spacing)
		if !left {
			offset++
		}
		for offset < 88 {
			t, code := wire.ReadTick(data, uint64(offset))
			if code != 0 {
				return 0, 0, code
			}
			if t.Initialized == 1 {
				return index, start + offset*spacing, 0
			}
			if left {
				offset--
			} else {
				offset++
			}
		}
		if left && !math.TickLess(4294523660, start) {
			return index, 4294523660, 0
		}
		if !left && math.TickLess(443636, start+88*spacing) {
			return index, 443636, 0
		}
		if index == 2 {
			if left {
				return index, start, 0
			}
			return index, start + 88*spacing - 1, 0
		}
		if left {
			search = start - 1
		} else {
			search = start + 88*spacing - 1
		}
		index++
	}
	return 0, 0, 6038
}

func Apply(pool, a0, a1, a2 []byte, poolKey wire.Key, args Args, timestamp uint64) (Result, uint64) {
	var out Result
	if uint64(len(pool)) < wire.PoolSize {
		return out, wire.ErrLayout
	}
	// Anchor Whirlpool discriminator. The remainder is retained byte-for-byte.
	if pool[0] != 63 || pool[1] != 149 || pool[2] != 209 || pool[3] != 12 || pool[4] != 225 || pool[5] != 128 || pool[6] != 99 || pool[7] != 9 {
		return out, wire.ErrLayout
	}
	for j := uint64(0); j < 3; j++ {
		code := wire.CheckTickArray(Array(a0, a1, a2, j), poolKey)
		if code != 0 {
			return out, code
		}
	}
	return applyValidated(pool, a0, a1, a2, args, timestamp)
}

// applyValidated is private: its callers validate these exact buffers and
// pool key in the same invocation, with no writes or CPIs before this call.
func applyValidated(pool, a0, a1, a2 []byte, args Args, timestamp uint64) (Result, uint64) {
	var out Result
	if uint64(len(pool)) < wire.PoolSize {
		return out, wire.ErrLayout
	}
	// Anchor Whirlpool discriminator. The remainder is retained byte-for-byte.
	if pool[0] != 63 || pool[1] != 149 || pool[2] != 209 || pool[3] != 12 || pool[4] != 225 || pool[5] != 128 || pool[6] != 99 || pool[7] != 9 {
		return out, wire.ErrLayout
	}
	spacing := wire.Read16(pool, 41)
	if spacing == 0 {
		return out, 6004
	}
	feeRate := wire.Read16(pool, 45)
	protocolRate := wire.Read16(pool, 47)
	// Only the fixed-fee manager branch is ported in this first slice.
	if wire.Read16(pool, 43) != spacing {
		return out, ErrUnsupported
	}
	current := wire.Read128(pool, 65)
	limit := args.Limit
	if limit.IsZero() {
		if args.AToB {
			limit = math.MinPrice()
		} else {
			limit = math.MaxPrice()
		}
	}
	if limit.Less(math.MinPrice()) || math.MaxPrice().Less(limit) {
		return out, 6011
	}
	if (args.AToB && !limit.Less(current)) || (!args.AToB && !current.Less(limit)) {
		return out, 6034
	}
	if args.Amount == 0 {
		return out, 6035
	}
	last := wire.Read64(pool, 261)
	if timestamp < last {
		return out, 6022
	}
	liquidity := wire.Read128(pool, 49)
	// Same checked product and overflow-to-zero policy as next_whirlpool_reward_infos.
	for j := uint64(0); j < 3; j++ {
		o := 269 + j*128
		if wire.ReadKey(pool, o) != (wire.Key{}) && !liquidity.IsZero() && timestamp != last {
			delta, code := math.MulDiv(math.U128{Lo: timestamp - last}, wire.Read128(pool, o+96), liquidity, false)
			if code != 0 {
				delta = math.U128{}
			}
			next, _ := math.Add128(wire.Read128(pool, o+112), delta)
			wire.Write128(pool, o+112, next)
		}
	}
	remaining, calculated := args.Amount, uint64(0)
	tick := wire.Read32(pool, 81)
	arrayIndex := uint64(0)
	feeA, feeB := wire.Read128(pool, 165), wire.Read128(pool, 245)
	feeGlobal := feeB
	if args.AToB {
		feeGlobal = feeA
	}
	feeSum, protocolSum := uint64(0), uint64(0)
	for remaining > 0 && !current.Eq(limit) {
		index, nextTick, code := NextTick(a0, a1, a2, tick, spacing, args.AToB, arrayIndex)
		if code != 0 {
			return out, code
		}
		tickPrice, code := math.SqrtPriceFromTick(nextTick)
		if code != 0 {
			return out, code
		}
		target := tickPrice
		if args.AToB {
			if target.Less(limit) {
				target = limit
			}
		} else {
			if limit.Less(target) {
				target = limit
			}
		}
		step, code := math.ComputeSwap(remaining, feeRate, liquidity, current, target, args.Input, args.AToB)
		if code != 0 {
			return out, code
		}
		used, added := step.AmountOut, step.AmountIn
		if args.Input {
			used = step.AmountIn
			if used > 18446744073709551615-step.Fee {
				return out, 6040
			}
			used = used + step.Fee
			added = step.AmountOut
		} else {
			if added > 18446744073709551615-step.Fee {
				return out, 6039
			}
			added = added + step.Fee
		}
		if used > remaining {
			return out, 6040
		}
		remaining = remaining - used
		if added > 18446744073709551615-calculated || step.Fee > 18446744073709551615-feeSum {
			return out, 6039
		}
		calculated = calculated + added
		feeSum = feeSum + step.Fee
		pf, _ := math.MulDiv(math.U128{Lo: step.Fee}, math.U128{Lo: uint64(protocolRate)}, math.U128{Lo: 10000}, false)
		protocolSum = protocolSum + pf.Lo
		if !liquidity.IsZero() {
			growth, _ := math.DivRound128(math.U128{Hi: step.Fee - pf.Lo}, liquidity, false)
			feeGlobal, _ = math.Add128(feeGlobal, growth)
		}
		if step.NextPrice.Eq(tickPrice) {
			data := Array(a0, a1, a2, index)
			offset := FloorOffset(nextTick-wire.Read32(data, 8), spacing)
			t, readCode := wire.ReadTick(data, uint64(offset))
			if readCode == 0 && t.Initialized == 1 {
				delta := t.Net
				if args.AToB {
					delta = math.Neg128(delta)
				}
				liquidity, code = math.AddLiquidity(liquidity, delta)
				if code != 0 {
					return out, code
				}
				globalA, globalB := feeA, feeB
				if args.AToB {
					globalA = feeGlobal
				} else {
					globalB = feeGlobal
				}
				t.FeeA, _ = math.Sub128(globalA, t.FeeA)
				t.FeeB, _ = math.Sub128(globalB, t.FeeB)
				if wire.ReadKey(pool, 269) != (wire.Key{}) {
					t.Reward0, _ = math.Sub128(wire.Read128(pool, 381), t.Reward0)
				}
				if wire.ReadKey(pool, 397) != (wire.Key{}) {
					t.Reward1, _ = math.Sub128(wire.Read128(pool, 509), t.Reward1)
				}
				if wire.ReadKey(pool, 525) != (wire.Key{}) {
					t.Reward2, _ = math.Sub128(wire.Read128(pool, 637), t.Reward2)
				}
				code = wire.WriteTick(data, uint64(offset), t)
				if code != 0 {
					return out, code
				}
				out.Crossings++
			}
			arrayIndex = index
			if (args.AToB && offset == 0) || (!args.AToB && offset == 87) {
				arrayIndex++
			}
			tick = nextTick
			if args.AToB {
				tick--
			}
		} else if !step.NextPrice.Eq(current) {
			tick, code = math.TickFromSqrtPrice(step.NextPrice)
			if code != 0 {
				return out, code
			}
		}
		current = step.NextPrice
	}
	if remaining > 0 && !args.Input && args.Limit.IsZero() {
		return out, 6057
	}
	if args.AToB == args.Input {
		out.AmountA = args.Amount - remaining
		out.AmountB = calculated
	} else {
		out.AmountA = calculated
		out.AmountB = args.Amount - remaining
	}
	inputAmount, outputAmount := out.AmountB, out.AmountA
	if args.AToB {
		inputAmount = out.AmountA
		outputAmount = out.AmountB
	}
	if args.Input && args.Threshold > outputAmount {
		return out, 6036
	}
	if !args.Input && args.Threshold < inputAmount {
		return out, 6037
	}
	wire.Write128(pool, 49, liquidity)
	wire.Write128(pool, 65, current)
	wire.Write32(pool, 81, tick)
	if args.AToB {
		wire.Write128(pool, 165, feeGlobal)
		wire.Write64(pool, 85, wire.Read64(pool, 85)+protocolSum)
	} else {
		wire.Write128(pool, 245, feeGlobal)
		wire.Write64(pool, 93, wire.Read64(pool, 93)+protocolSum)
	}
	wire.Write64(pool, 261, timestamp)
	out.ProtocolFee = protocolSum
	out.LPFee = feeSum - protocolSum
	return out, 0
}
