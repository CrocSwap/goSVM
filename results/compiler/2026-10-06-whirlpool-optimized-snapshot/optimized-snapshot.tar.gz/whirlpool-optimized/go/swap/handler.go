// Package handler implements Orca's classic-token Swap account/wire interface.
// Scope: fixed-fee pools, three complete consecutive fixed arrays; no events yet.
package swap

import (
	"example.org/gosvm-benchmarks/whirlpool/math"
	"example.org/gosvm-benchmarks/whirlpool/wire"
	"gosvm/sdk/cpi"
	"gosvm/sdk/pda"
	"gosvm/sdk/token"
	"gosvm/solana"
)

func equal(a, b []byte) bool {
	if len(a) != len(b) {
		return false
	}
	for j := uint64(0); j < uint64(len(a)); j++ {
		if a[j] != b[j] {
			return false
		}
	}
	return true
}
func zero(b []byte) bool {
	for j := uint64(0); j < uint64(len(b)); j++ {
		if b[j] != 0 {
			return false
		}
	}
	return true
}
func loadToken(c solana.Context, i uint64) uint64 {
	id := token.ProgramID()
	if !equal(solana.Owner(c, i), id[:]) {
		return 3007
	}
	b := solana.Data(c, i)
	// SPL Pack validates the initialized state and every COption tag.
	if len(b) != 165 {
		return 4 << 32
	}
	if (b[108] != 1 && b[108] != 2) || wire.Read32(b, 72) > 1 || wire.Read32(b, 109) > 1 || wire.Read32(b, 129) > 1 {
		return 4 << 32
	}
	return 0
}
func checkOracleAddress(c solana.Context) uint64 {
	var prefix [6]byte
	prefix[0] = 111
	prefix[1] = 114
	prefix[2] = 97
	prefix[3] = 99
	prefix[4] = 108
	prefix[5] = 101
	for bump := uint32(255); bump > 0; bump-- {
		var seeds pda.Seeds
		seeds.AddBytes(prefix[:])
		seeds.AddBytes(solana.Key(c, 2))
		seeds.AddByte(byte(bump))
		var address [32]byte
		if solana.CreateAddress(c, seeds.Bytes(), solana.ProgramID(c), address[:]) == 0 {
			if !equal(address[:], solana.Key(c, 10)) {
				return 2006
			}
			return 0
		}
	}
	return 2006
}
func checkOracle(c solana.Context, timestamp uint64) uint64 {
	b := solana.Data(c, 10)
	if len(b) == 0 && zero(solana.Owner(c, 10)) {
		return 0
	}
	if !equal(solana.Owner(c, 10), solana.ProgramID(c)) {
		return 3007
	}
	if len(b) < 8 {
		return 3001
	}
	if b[0] != 139 || b[1] != 194 || b[2] != 131 || b[3] != 179 || b[4] != 140 || b[5] != 179 || b[6] != 229 || b[7] != 244 {
		return 3002
	}
	if len(b) < 254 {
		return 7000
	}
	if !equal(b[8:40], solana.Key(c, 2)) {
		return 7000
	}
	if timestamp < wire.Read64(b, 40) {
		return 6064
	}
	// An initialized oracle supplies adaptive-fee information even for a pool
	// whose fee-tier seed equals tick spacing. It cannot be silently ignored.
	return 7001
}
func transfer(c solana.Context, source, destination, authority, amount uint64, seeds *cpi.SingleSigner) uint64 {
	var data [9]byte
	data[0] = 3
	wire.Write64(data[:], 1, amount)
	var metas cpi.Metas
	metas.Add(source, true, false)
	metas.Add(destination, true, false)
	metas.Add(authority, false, true)
	if seeds == nil {
		return cpi.Invoke(c, 0, &metas, data[:], nil)
	}
	return cpi.InvokeSingle(c, 0, &metas, data[:], seeds)
}
func withdraw(c solana.Context, source, destination, amount uint64) uint64 {
	pool := solana.Data(c, 2)
	var prefix [9]byte
	prefix[0] = 119
	prefix[1] = 104
	prefix[2] = 105
	prefix[3] = 114
	prefix[4] = 108
	prefix[5] = 112
	prefix[6] = 111
	prefix[7] = 111
	prefix[8] = 108
	var seeds cpi.SingleSigner
	seeds.AddBytes(prefix[:])
	seeds.AddBytes(pool[8:40])
	seeds.AddBytes(pool[101:133])
	seeds.AddBytes(pool[181:213])
	seeds.AddBytes(pool[43:45])
	seeds.AddByte(pool[40])
	return transfer(c, source, destination, 2, amount, &seeds)
}
func ProcessHandler(c solana.Context) uint64 {
	d := solana.Instruction(c)
	if len(d) < 8 {
		return 100
	}
	if d[0] != 248 || d[1] != 198 || d[2] != 158 || d[3] != 145 || d[4] != 225 || d[5] != 117 || d[6] != 135 || d[7] != 200 {
		return 101
	}
	if len(d) < 42 || d[40] > 1 || d[41] > 1 {
		return 102
	}
	if solana.Count(c) < 11 {
		return 3005
	}
	id := token.ProgramID()
	if !equal(solana.Key(c, 0), id[:]) {
		return 3008
	}
	if !solana.Executable(c, 0) {
		return 3009
	}
	if !solana.Signer(c, 1) {
		return 3010
	}
	pool := solana.Data(c, 2)
	if zero(solana.Owner(c, 2)) && solana.Lamports(c, 2) == 0 {
		return 3012
	}
	if !equal(solana.Owner(c, 2), solana.ProgramID(c)) {
		return 3007
	}
	if len(pool) < 8 {
		return 3001
	}
	if pool[0] != 63 || pool[1] != 149 || pool[2] != 209 || pool[3] != 12 || pool[4] != 225 || pool[5] != 128 || pool[6] != 99 || pool[7] != 9 {
		return 3002
	}
	if len(pool) < 653 {
		return 3003
	}
	for i := uint64(3); i < 7; i++ {
		code := loadToken(c, i)
		if code != 0 {
			return code
		}
	}
	for i := uint64(2); i < 10; i++ {
		if !solana.Writable(c, i) {
			return 2000
		}
	}
	if !equal(solana.Data(c, 3)[:32], pool[101:133]) {
		return 2003
	}
	if !equal(solana.Key(c, 4), pool[133:165]) {
		return 2012
	}
	if !equal(solana.Data(c, 5)[:32], pool[181:213]) {
		return 2003
	}
	if !equal(solana.Key(c, 6), pool[213:245]) {
		return 2012
	}
	code := checkOracleAddress(c)
	if code != 0 {
		return code
	}
	var clock [40]byte
	code = solana.Clock(c, clock[:])
	if code != 0 {
		return code
	}
	timestamp := wire.Read64(clock[:], 32)
	if timestamp>>63 != 0 {
		return 6021
	}
	key := wire.ReadKey(solana.Key(c, 2), 0)
	for i := uint64(7); i < 10; i++ {
		if !equal(solana.Owner(c, i), solana.ProgramID(c)) {
			return 3007
		}
		b := solana.Data(c, i)
		if len(b) < 8 {
			return 3001
		}
		if b[0] != 69 || b[1] != 97 || b[2] != 189 || b[3] != 190 || b[4] != 110 || b[5] != 7 || b[6] != 66 || b[7] != 187 {
			return 3002
		}
		code = wire.CheckTickArray(b, key)
		if code != 0 {
			return code
		}
	}
	left := d[41] == 1
	spacing := wire.Read16(pool, 41)
	if spacing == 0 {
		return 6004
	}
	span := spacing * 88
	tick := wire.Read32(pool, 81)
	start := FloorOffset(tick, span) * span
	if !left && !math.TickLess(tick+spacing, start+span) {
		start = start + span
	}
	var order [3]uint64
	for j := uint64(0); j < 3; j++ {
		found := false
		for i := uint64(7); i < 10; i++ {
			if wire.Read32(solana.Data(c, i), 8) == start {
				order[j] = i
				found = true
				break
			}
		}
		if !found {
			if j == 0 {
				return 6023
			}
			return 7001
		}
		if left {
			start = start - span
		} else {
			start = start + span
		}
	}
	code = checkOracle(c, timestamp)
	if code != 0 {
		return code
	}
	args := Args{Amount: wire.Read64(d, 8), Threshold: wire.Read64(d, 16), Limit: wire.Read128(d, 24), Input: d[40] == 1, AToB: left}
	result, status := applyValidated(pool, solana.Data(c, order[0]), solana.Data(c, order[1]), solana.Data(c, order[2]), args, timestamp)
	if status != 0 {
		return status
	}
	if left {
		code = transfer(c, 3, 4, 1, result.AmountA, nil)
		if code != 0 {
			return code
		}
		return withdraw(c, 6, 5, result.AmountB)
	}
	code = transfer(c, 5, 6, 1, result.AmountB, nil)
	if code != 0 {
		return code
	}
	return withdraw(c, 4, 3, result.AmountA)
}
