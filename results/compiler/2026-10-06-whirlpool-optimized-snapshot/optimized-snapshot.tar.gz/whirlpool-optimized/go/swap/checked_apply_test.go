package swap
import("testing";"example.org/gosvm-benchmarks/whirlpool/wire")
func TestApplyRechecksPreviouslyValidatedArrays(t *testing.T){
 for _,kind:=range []string{"flag","pool","discriminator","short"}{
  for index:=0;index<3;index++{
   pool:=make([]byte,653);copy(pool,[]byte{63,149,209,12,225,128,99,9})
   key:=wire.Key{7,8,9};arrays:=[][]byte{make([]byte,9988),make([]byte,9988),make([]byte,9988)}
   for _,b:=range arrays{copy(b,[]byte{69,97,189,190,110,7,66,187});copy(b[9956:],key[:]);if code:=wire.CheckTickArray(b,key);code!=0{t.Fatal(code)}}
   want:=wire.ErrLayout
   switch kind{case "flag":arrays[index][12+87*113]=2;case "pool":arrays[index][9956]++;want=6056;case "discriminator":arrays[index][0]++;case "short":arrays[index]=arrays[index][:9987]}
   out,code:=Apply(pool,arrays[0],arrays[1],arrays[2],key,Args{},0)
   if code!=want||out!=(Result{}){t.Fatal(kind,index,out,code,want)}
  }
 }
}
