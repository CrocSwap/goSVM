package swap

import (
	"bytes"
	"compress/gzip"
	"encoding/hex"
	"encoding/json"
	"example.org/gosvm-benchmarks/whirlpool/math"
	"example.org/gosvm-benchmarks/whirlpool/wire"
	"math/big"
	"os"
	"testing"
)

type swapRequest struct {
	Pool                         string
	Arrays                       []string
	A                            string
	Amount, Timestamp, Threshold uint64
	Input                        bool
	AToB                         bool `json:"a_to_b"`
}
type swapResponse struct {
	Pool        string
	Arrays      []string
	Code        uint64
	AmountA     uint64 `json:"amount_a"`
	AmountB     uint64 `json:"amount_b"`
	LPFee       uint64 `json:"lp_fee"`
	ProtocolFee uint64 `json:"protocol_fee"`
}
type swapVector struct {
	Name     string
	Request  swapRequest
	Expected swapResponse
}

func decode(s string) []byte {
	b, err := hex.DecodeString(s)
	if err != nil {
		panic(err)
	}
	return b
}
func TestPinnedRustSwapManager(t *testing.T) {
	f, err := os.Open("../testdata/swap.json.gz")
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	z, err := gzip.NewReader(f)
	if err != nil {
		t.Fatal(err)
	}
	defer z.Close()
	var cases []swapVector
	if err = json.NewDecoder(z).Decode(&cases); err != nil {
		t.Fatal(err)
	}
	if len(cases) < 100 {
		t.Fatal("incomplete corpus")
	}
	crossings := uint64(0)
	for _, c := range cases {
		r := c.Request
		pool := decode(r.Pool)
		a0, a1, a2 := decode(r.Arrays[0]), decode(r.Arrays[1]), decode(r.Arrays[2])
		limit, ok := new(big.Int).SetString(r.A, 10)
		if !ok {
			t.Fatal("bad limit")
		}
		args := Args{Amount: r.Amount, Threshold: r.Threshold, Limit: math.U128{Lo: limit.Uint64(), Hi: new(big.Int).Rsh(limit, 64).Uint64()}, Input: r.Input, AToB: r.AToB}
		var key wire.Key
		for i := range key {
			key[i] = 5
		}
		result, code := Apply(pool, a0, a1, a2, key, args, r.Timestamp)
		if code != c.Expected.Code {
			t.Fatalf("%s code %d want %d", c.Name, code, c.Expected.Code)
		}
		if code != 0 {
			continue
		}
		crossings += result.Crossings
		if result.AmountA != c.Expected.AmountA || result.AmountB != c.Expected.AmountB || result.LPFee != c.Expected.LPFee || result.ProtocolFee != c.Expected.ProtocolFee {
			t.Fatalf("%s result %+v want %+v", c.Name, result, c.Expected)
		}
		if !bytes.Equal(pool, decode(c.Expected.Pool)) {
			t.Fatalf("%s pool state", c.Name)
		}
		for i, data := range [][]byte{a0, a1, a2} {
			if !bytes.Equal(data, decode(c.Expected.Arrays[i])) {
				t.Fatalf("%s array %d", c.Name, i)
			}
		}
	}
	if crossings < 100 {
		t.Fatal("tick-crossing coverage missing", crossings)
	}
	t.Logf("%d exact upstream swap states; %d initialized tick crossings", len(cases), crossings)
}
