# Go Whirlpools core

Read [the parent scope/evidence document](../README.md) before interpreting this
port. The shared `math`, `wire` and `swap` packages are compiled by goSVM and used
directly by ordinary native Go tests.

The root program and `gosvm.json` form a generated schema-2 / SDK-2 swap-step
math adapter. `model` contains canonical arguments/results and `client` contains
generated codecs. It uses test-specific goSVM discriminators and one program-owned
output account; it is not the upstream Whirlpools instruction.

`probe/` is a separate handwritten swap-core test adapter. It preserves actual
Orca pool/fixed-tick account bytes and embeds the exact Orca swap payload, adding
one test opcode and an explicit timestamp. It does not transfer tokens. Runtime
verification supplies preloaded accounts and checks full post-state/rollback.

Use the pinned CLI identified by `../../../tools/gosvm.lock.json`; the generated
SDK must match it. Prefer root `make test` / `make verify` for the recorded host
cache and reproducible actual-SBF checks. No rent/resize/close operation is used.
