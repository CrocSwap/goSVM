package math

type Step struct {
	AmountIn  uint64
	AmountOut uint64
	NextPrice U128
	Fee       uint64
}

func MinPrice() U128 { return U128{Lo: 4295048016} }
func MaxPrice() U128 { return U128{Lo: 3871828160200520623, Hi: 4294886577} }

// The exceeds flag has the same meaning as Rust's AmountDeltaU64::ExceedsMax.
func DeltaA(p0, p1, liquidity U128, up bool) (uint64, bool, uint64) {
	lo, hi := p0, p1
	if hi.Less(lo) {
		lo, hi = hi, lo
	}
	diff, _ := Sub128(hi, lo)
	n, over := Mul128(liquidity, diff).ShiftLeftWord()
	if over {
		return 0, false, MultiplicationOverflow
	}
	q, code := DivRound(n, Mul128(hi, lo), up)
	if code != 0 {
		if code == NumberDownCast {
			return 0, true, code
		}
		return 0, false, code
	}
	if q.Hi != 0 {
		return 0, true, TokenMaxExceeded
	}
	return q.Lo, false, 0
}
func DeltaB(p0, p1, liquidity U128, up bool) (uint64, bool, uint64) {
	lo, hi := p0, p1
	if hi.Less(lo) {
		lo, hi = hi, lo
	}
	diff, _ := Sub128(hi, lo)
	p := Mul128(liquidity, diff)
	if p.L[2] != 0 || p.L[3] != 0 {
		return 0, true, MultiplicationShiftRightOverflow
	}
	v := p.L[1]
	if up && p.L[0] != 0 {
		if v == 18446744073709551615 {
			return 0, true, MultiplicationOverflow
		}
		v++
	}
	return v, false, 0
}
func FixedDelta(p0, p1, liquidity U128, input, aToB bool) (uint64, bool, uint64) {
	if input == aToB {
		return DeltaA(p0, p1, liquidity, input)
	}
	return DeltaB(p0, p1, liquidity, input)
}
func UnfixedDelta(p0, p1, liquidity U128, input, aToB bool) (uint64, uint64) {
	var v, code uint64
	var exceeds bool
	if input == aToB {
		v, exceeds, code = DeltaB(p0, p1, liquidity, !input)
	} else {
		v, exceeds, code = DeltaA(p0, p1, liquidity, !input)
	}
	if exceeds || code != 0 {
		return 0, code
	}
	return v, 0
}
func NextPrice(price, liquidity U128, amount uint64, input, aToB bool) (U128, uint64) {
	if input == aToB {
		if amount == 0 {
			return price, 0
		}
		product := Mul128(price, U128{Lo: amount})
		numerator, over := Mul128(liquidity, price).ShiftLeftWord()
		if over {
			return U128{}, MultiplicationOverflow
		}
		shifted, _ := liquidity.Wide().ShiftLeftWord()
		if !input && !product.Less(shifted) {
			return U128{}, DivideByZero
		}
		denominator := Sub256(shifted, product)
		if input {
			denominator, _ = Add256(shifted, product)
		}
		next, code := DivRoundWords(numerator, denominator, true)
		if code != 0 {
			return U128{}, code
		}
		if next.Less(MinPrice()) {
			return U128{}, TokenMinSubceeded
		}
		if MaxPrice().Less(next) {
			return U128{}, TokenMaxExceeded
		}
		return next, 0
	}
	delta, code := DivRound128(U128{Hi: amount}, liquidity, !input)
	if code != 0 {
		return U128{}, code
	}
	var next U128
	var over bool
	if input {
		next, over = Add128(price, delta)
	} else {
		next, over = Sub128(price, delta)
	}
	if over {
		return U128{}, PriceOutOfBounds
	}
	return next, 0
}

// ComputeSwap mirrors the pinned math::compute_swap, including its initial
// delta overflow sentinel and asymmetric exact-in/exact-out rounding.
func ComputeSwap(remaining uint64, feeRate uint32, liquidity, current, target U128, input, aToB bool) (Step, uint64) {
	var result Step
	fixed, exceeds, code := FixedDelta(current, target, liquidity, input, aToB)
	if code != 0 && !exceeds {
		return result, code
	}
	calc := remaining
	if input {
		v, err := MulDiv(U128{Lo: remaining}, U128{Lo: 1000000 - uint64(feeRate)}, U128{Lo: 1000000}, false)
		if err != 0 {
			return result, err
		}
		calc = v.Lo
	}
	next := target
	if exceeds || fixed > calc {
		next, code = NextPrice(current, liquidity, calc, input, aToB)
		if code != 0 {
			return result, code
		}
	}
	maxSwap := next.Eq(target)
	unfixed, code := UnfixedDelta(current, next, liquidity, input, aToB)
	if code != 0 {
		return result, code
	}
	if !maxSwap || exceeds {
		fixed, exceeds, code = FixedDelta(current, next, liquidity, input, aToB)
		if code != 0 || exceeds {
			return result, code
		}
	}
	amountIn, amountOut := fixed, unfixed
	if !input {
		amountIn, amountOut = unfixed, fixed
	}
	if !input && amountOut > remaining {
		amountOut = remaining
	}
	fee := uint64(0)
	if input && !maxSwap {
		fee = remaining - amountIn
	} else {
		value, err := MulDiv(U128{Lo: amountIn}, U128{Lo: uint64(feeRate)}, U128{Lo: 1000000 - uint64(feeRate)}, true)
		if err != 0 {
			return result, err
		}
		if value.Hi != 0 {
			return result, NumberCast
		}
		fee = value.Lo
	}
	return Step{amountIn, amountOut, next, fee}, 0
}
