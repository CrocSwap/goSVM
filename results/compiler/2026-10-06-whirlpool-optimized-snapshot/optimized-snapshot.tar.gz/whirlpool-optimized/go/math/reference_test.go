package math

import (
	"encoding/json"
	"math/big"
	"os"
	"testing"
)

type request struct {
	Op         string
	A, B, C, D string
	Amount     uint64
	Fee        uint32
	Input      bool
	AToB       bool `json:"a_to_b"`
	Tick       int32
}
type response struct {
	Code      uint64
	Value     string
	AmountIn  uint64 `json:"amount_in"`
	AmountOut uint64 `json:"amount_out"`
	Fee       uint64
	Tick      int32
}
type vector struct {
	Name     string
	Request  request
	Expected response
}

func parse128(s string) U128 {
	if s == "" {
		return U128{}
	}
	v, ok := new(big.Int).SetString(s, 10)
	if !ok || v.Sign() < 0 || v.BitLen() > 128 {
		panic("invalid fixture integer")
	}
	return small128(v)
}
func TestPinnedRustMath(t *testing.T)       { testRustVectors(t, "../testdata/math.json") }
func TestOptimizationRustMath(t *testing.T) { testRustVectors(t, "../testdata/optimization.json") }
func TestWideOptimizationRustMath(t *testing.T) {
	testRustVectors(t, "../testdata/wide_optimization.json")
}
func testRustVectors(t *testing.T, path string) {
	t.Helper()
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal("generate pinned Rust vectors:", err)
	}
	var vectors []vector
	if err = json.Unmarshal(data, &vectors); err != nil {
		t.Fatal(err)
	}
	if len(vectors) < 3000 {
		t.Fatal("incomplete corpus")
	}
	for _, v := range vectors {
		r := v.Request
		a, b, c, d := parse128(r.A), parse128(r.B), parse128(r.C), parse128(r.D)
		var got U128
		code := uint64(0)
		switch r.Op {
		case "step":
			var step Step
			step, code = ComputeSwap(r.Amount, r.Fee, a, b, c, r.Input, r.AToB)
			got = step.NextPrice
			if code == 0 && (step.AmountIn != v.Expected.AmountIn || step.AmountOut != v.Expected.AmountOut || step.Fee != v.Expected.Fee) {
				t.Fatalf("%s step %+v want %+v", v.Name, step, v.Expected)
			}
		case "next_price":
			got, code = NextPrice(a, b, r.Amount, r.Input, r.AToB)
		case "delta_a":
			var amount uint64
			amount, _, code = DeltaA(a, b, c, r.Input)
			got.Lo = amount
		case "delta_b":
			var amount uint64
			amount, _, code = DeltaB(a, b, c, r.Input)
			got.Lo = amount
		case "sqrt":
			got, code = SqrtPriceFromTick(uint32(r.Tick))
		case "tick":
			var tick uint32
			tick, code = TickFromSqrtPrice(a)
			if int32(tick) != v.Expected.Tick {
				t.Fatalf("%s tick %d want %d", v.Name, int32(tick), v.Expected.Tick)
			}
		case "liquidity":
			got, code = AddLiquidity(a, b)
		case "mul_div":
			got, code = MulDiv(a, b, c, r.Input)
		case "div256":
			got, code = DivRound(U256{L: [4]uint64{b.Lo, b.Hi, a.Lo, a.Hi}}, U256{L: [4]uint64{d.Lo, d.Hi, c.Lo, c.Hi}}, r.Input)
		default:
			t.Fatal("unknown operation", r.Op)
		}
		if code != v.Expected.Code {
			t.Fatalf("%s %s code %d want %d request %+v", v.Name, r.Op, code, v.Expected.Code, r)
		}
		if code == 0 && r.Op != "tick" && !got.Eq(parse128(v.Expected.Value)) {
			t.Fatalf("%s value %s want %s", v.Name, big128(got), v.Expected.Value)
		}
	}
	t.Logf("%d exact upstream math vectors", len(vectors))
}
