// Tick factors are transcribed from pinned Orca tick_math.rs. See THIRD_PARTY_NOTICES.
package math

// Signed tick indices retain their i32 two's-complement wire bits.
func TickLess(a, b uint32) bool { return (a ^ 2147483648) < (b ^ 2147483648) }
func SqrtPriceFromTick(tick uint32) (U128, uint64) {
	negative := tick>>31 != 0
	magnitude := tick
	if negative {
		magnitude = 0 - tick
	}
	if magnitude > 443636 {
		return U128{}, 6010
	}
	var ratio U128
	if negative {
		if magnitude&1 != 0 {
			ratio = U128{Lo: 18445821805675392311, Hi: 0}
		} else {
			ratio = U128{Lo: 0, Hi: 1}
		}
		if magnitude&2 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 18444899583751176498, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&4 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 18443055278223354162, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&8 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 18439367220385604838, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&16 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 18431993317065449817, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&32 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 18417254355718160513, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&64 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 18387811781193591352, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&128 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 18329067761203520168, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&256 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 18212142134806087854, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&512 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 17980523815641551639, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&1024 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 17526086738831147013, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&2048 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 16651378430235024244, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&4096 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 15030750278693429944, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&8192 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 12247334978882834399, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&16384 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 8131365268884726200, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&32768 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 3584323654723342297, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&65536 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 696457651847595233, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&131072 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 26294789957452057, Hi: 0}).ShiftRight(64).Narrow()
		}
		if magnitude&262144 != 0 {
			ratio, _ = Mul128(ratio, U128{Lo: 37481735321082, Hi: 0}).ShiftRight(64).Narrow()
		}
		return ratio, 0
	}
	if magnitude&1 != 0 {
		ratio = U128{Lo: 18379584988209926159, Hi: 4295182038}
	} else {
		ratio = U128{Lo: 0, Hi: 4294967296}
	}
	if magnitude&2 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 13458744476178488859, Hi: 4295396792}).ShiftRight(96).Narrow()
	}
	if magnitude&4 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 7542374851780082549, Hi: 4295826332}).ShiftRight(96).Narrow()
	}
	if magnitude&8 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 11688190168964099665, Hi: 4296685540}).ShiftRight(96).Narrow()
	}
	if magnitude&16 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 12325950504610477152, Hi: 4298404472}).ShiftRight(96).Narrow()
	}
	if magnitude&32 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 743749799984496066, Hi: 4301844400}).ShiftRight(96).Narrow()
	}
	if magnitude&64 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 12976902672507316901, Hi: 4308732515}).ShiftRight(96).Narrow()
	}
	if magnitude&128 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 8371584169514950494, Hi: 4322541852}).ShiftRight(96).Narrow()
	}
	if magnitude&256 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 2262161228410220004, Hi: 4350293443}).ShiftRight(96).Narrow()
	}
	if magnitude&512 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 14459650751607002531, Hi: 4406332280}).ShiftRight(96).Narrow()
	}
	if magnitude&1024 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 7840076245800284593, Hi: 4520584868}).ShiftRight(96).Narrow()
	}
	if magnitude&2048 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 7174944039344897962, Hi: 4758054286}).ShiftRight(96).Narrow()
	}
	if magnitude&4096 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 358097327435643877, Hi: 5271071706}).ShiftRight(96).Narrow()
	}
	if magnitude&8192 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 11388944843577404226, Hi: 6469012454}).ShiftRight(96).Narrow()
	}
	if magnitude&16384 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 1754717824462694519, Hi: 9743525213}).ShiftRight(96).Narrow()
	}
	if magnitude&32768 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 11498634451058391528, Hi: 22104076011}).ShiftRight(96).Narrow()
	}
	if magnitude&65536 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 5866026427582439525, Hi: 113758765237}).ShiftRight(96).Narrow()
	}
	if magnitude&131072 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 17854934707512043213, Hi: 3013074553645}).ShiftRight(96).Narrow()
	}
	if magnitude&262144 != 0 {
		ratio, _ = Mul128(ratio, U128{Lo: 10158072769176329423, Hi: 2113780534320708}).ShiftRight(96).Narrow()
	}
	ratio, _ = ratio.Wide().ShiftRight(32).Narrow()
	return ratio, 0
}

// Same fourteen-bit logarithmic approximation and correction as Orca.
// Signed intermediate arithmetic is represented modulo 2^128; all real values
// fit i128. Taking the high limb implements the floor of arithmetic >> 64.
func TickFromSqrtPrice(price U128) (uint32, uint64) {
	if price.Less(MinPrice()) || MaxPrice().Less(price) {
		return 0, PriceOutOfBounds
	}
	msb := uint64(0)
	word := price.Lo
	if price.Hi != 0 {
		word = price.Hi
		msb = 64
	}
	msb = msb + BitLen64(word) - 1
	integer, _ := Sub128(U128{Lo: msb}, U128{Lo: 64})
	integer = U128{Lo: integer.Lo << 32, Hi: integer.Hi<<32 | integer.Lo>>32}
	// Normalization leaves r in [2^63, 2^64); only one word is needed.
	r := uint64(0)
	if msb >= 64 {
		shift := msb - 63
		r = price.Lo>>shift | price.Hi<<(64-shift)
	} else {
		r = price.Lo << (63 - msb)
	}
	fraction := uint64(0)
	bit := uint64(9223372036854775808)
	for precision := uint64(0); precision < 14; precision++ {
		square := Mul64(r, r)
		more := square.Hi >> 63
		if more != 0 {
			r = square.Hi
		} else {
			r = square.Hi<<1 | square.Lo>>63
		}
		fraction = fraction + bit*more
		bit = bit >> 1
	}
	log2, _ := Add128(integer, U128{Lo: fraction >> 32})
	// Only the low 128 bits are used, including for negative i128 bits.
	product := Mul64(log2.Lo, 59543866431248)
	logBase := U128{Lo: product.Lo, Hi: product.Hi + log2.Hi*59543866431248}
	low, _ := Sub128(logBase, U128{Lo: 184467440737095516})
	high, _ := Add128(logBase, U128{Lo: 15793534762490258745})
	lo, hi := uint32(low.Hi), uint32(high.Hi)
	if lo == hi {
		return lo, 0
	}
	actual, _ := SqrtPriceFromTick(hi)
	if !price.Less(actual) {
		return hi, 0
	}
	return lo, 0
}
