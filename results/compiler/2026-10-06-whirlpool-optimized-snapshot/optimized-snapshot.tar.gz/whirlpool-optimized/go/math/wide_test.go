package math

import (
	"math/big"
	"math/rand"
	"testing"
)

func big128(a U128) *big.Int {
	return new(big.Int).Add(new(big.Int).Lsh(new(big.Int).SetUint64(a.Hi), 64), new(big.Int).SetUint64(a.Lo))
}
func big256(a U256) *big.Int {
	v := new(big.Int)
	for j := 3; j >= 0; j-- {
		v.Lsh(v, 64).Add(v, new(big.Int).SetUint64(a.L[j]))
	}
	return v
}
func small128(v *big.Int) U128 {
	return U128{v.Uint64(), new(big.Int).Rsh(new(big.Int).Set(v), 64).Uint64()}
}
func TestWideAgainstBigIntegers(t *testing.T) {
	rng := rand.New(rand.NewSource(20261005))
	mod := new(big.Int).Lsh(big.NewInt(1), 128)
	for i := 0; i < 5000; i++ {
		a, b := U128{rng.Uint64(), rng.Uint64()}, U128{rng.Uint64(), rng.Uint64()}
		av, bv := big128(a), big128(b)
		product := new(big.Int).Mul(av, bv)
		if big256(Mul128(a, b)).Cmp(product) != 0 {
			t.Fatalf("multiply %d", i)
		}
		r, over := Add128(a, b)
		sum := new(big.Int).Add(av, bv)
		if over != (sum.BitLen() > 128) || big128(r).Cmp(new(big.Int).Mod(sum, mod)) != 0 {
			t.Fatalf("add %d", i)
		}
		r, under := Sub128(a, b)
		diff := new(big.Int).Sub(av, bv)
		if under != (diff.Sign() < 0) || big128(r).Cmp(new(big.Int).Mod(diff, mod)) != 0 {
			t.Fatalf("subtract %d", i)
		}
		n := U256{L: [4]uint64{rng.Uint64(), rng.Uint64(), rng.Uint64(), rng.Uint64()}}
		d := U256{L: [4]uint64{rng.Uint64(), rng.Uint64(), rng.Uint64(), rng.Uint64()}}
		if i%3 == 0 {
			d = b.Wide()
		}
		q, rem, code := Div256(n, d)
		wantQ, wantR := new(big.Int), new(big.Int)
		wantQ.QuoRem(big256(n), big256(d), wantR)
		if code != 0 || big256(q).Cmp(wantQ) != 0 || big256(rem).Cmp(wantR) != 0 {
			t.Fatalf("divide %d", i)
		}
	}
}
func TestWideBoundaries(t *testing.T) {
	max := U128{18446744073709551615, 18446744073709551615}
	if _, code := DivRound(max.Wide(), U256{}, false); code != DivideByZero {
		t.Fatal(code)
	}
	if _, code := AddLiquidity(max, U128{Lo: 1}); code != LiquidityOverflow {
		t.Fatal(code)
	}
	if _, code := AddLiquidity(U128{}, Neg128(U128{Lo: 1})); code != LiquidityUnderflow {
		t.Fatal(code)
	}
	// i128::MIN must decode without a signed negation or narrowing overflow.
	minSigned := U128{Hi: 9223372036854775808}
	if v, code := AddLiquidity(minSigned, minSigned); code != 0 || !v.IsZero() {
		t.Fatal(v, code)
	}
	n := U256{L: [4]uint64{18446744073709551615, 18446744073709551615, 18446744073709551615, 18446744073709551615}}
	d := U256{L: [4]uint64{0, 0, 0, 9223372036854775808}}
	q, r, code := Div256(n, d)
	if code != 0 || q.L[0] != 1 || r.L[3] != 9223372036854775807 {
		t.Fatal(q, r, code)
	}
}

func TestBoundedDivisionAgainstBig(t *testing.T) {
	rng := rand.New(rand.NewSource(20261006))
	edges := []uint64{0, 1, 2, 1 << 31, 1<<32 - 1, 1 << 32, 1<<63 - 1, 1 << 63, ^uint64(0)}
	check := func(n, d U128) {
		t.Helper()
		q, r, code := Div128(n, d)
		if d.IsZero() {
			if code != DivideByZero {
				t.Fatal("zero", code)
			}
			return
		}
		wantQ, wantR := new(big.Int), new(big.Int)
		wantQ.QuoRem(big128(n), big128(d), wantR)
		if code != 0 || big128(q).Cmp(wantQ) != 0 || big128(r).Cmp(wantR) != 0 {
			t.Fatalf("n=%+v d=%+v q=%+v r=%+v code=%d want=%s %s", n, d, q, r, code, wantQ, wantR)
		}
		for _, up := range []bool{false, true} {
			got, err := DivRound128(n, d, up)
			fallback, fallbackErr := DivRound(n.Wide(), d.Wide(), up)
			if got != fallback || err != fallbackErr {
				t.Fatalf("round n=%+v d=%+v up=%v", n, d, up)
			}
		}
	}
	for _, a := range edges {
		for _, b := range edges {
			for _, c := range edges {
				for _, d := range edges {
					check(U128{a, b}, U128{c, d})
				}
			}
		}
	}
	for i := 0; i < 30000; i++ {
		n, d := U128{rng.Uint64(), rng.Uint64()}, U128{rng.Uint64(), rng.Uint64()}
		if i%3 == 0 {
			d.Hi = 0
		}
		if i%3 == 1 {
			n.Lo = 0
			d.Hi >>= uint(i % 64)
		}
		check(n, d)
		a, b := rng.Uint64(), rng.Uint64()
		if big128(Mul64(a, b)).Cmp(new(big.Int).Mul(new(big.Int).SetUint64(a), new(big.Int).SetUint64(b))) != 0 {
			t.Fatal("Mul64", a, b)
		}
	}
}

func TestNormalizedDivisionAgainstBig(t *testing.T) {
	rng := rand.New(rand.NewSource(20261007))
	check := func(n, d U256) {
		t.Helper()
		q, r, code := Div256Words(n, d)
		oldQ, oldR, oldCode := Div256(n, d)
		if q != oldQ || r != oldR || code != oldCode {
			t.Fatalf("fallback mismatch n=%+v d=%+v got=%+v %+v %d old=%+v %+v %d", n, d, q, r, code, oldQ, oldR, oldCode)
		}
		if d.IsZero() {
			return
		}
		wantQ, wantR := new(big.Int), new(big.Int)
		wantQ.QuoRem(big256(n), big256(d), wantR)
		if code != 0 || big256(q).Cmp(wantQ) != 0 || big256(r).Cmp(wantR) != 0 {
			t.Fatal("normalized divide", n, d, q, r, code, wantQ, wantR)
		}
		for _, up := range []bool{false, true} {
			a, b := DivRoundWords(n, d, up)
			x, y := DivRound(n, d, up)
			if a != x || b != y {
				t.Fatal("round", n, d, up, a, b, x, y)
			}
		}
	}
	words := []uint64{0, 1, 1 << 31, 1<<32 - 1, 1 << 32, 1<<63 - 1, 1 << 63, ^uint64(0)}
	for i := 0; i < 4; i++ {
		for _, nword := range words {
			for j := 0; j < 4; j++ {
				for _, dword := range words {
					n, d := U256{}, U256{}
					n.L[i] = nword
					d.L[j] = dword
					check(n, d)
					n.L[0] = ^uint64(0)
					check(n, d)
				}
			}
		}
	}
	for i := 0; i < 40000; i++ {
		n := U256{L: [4]uint64{rng.Uint64(), rng.Uint64(), rng.Uint64(), rng.Uint64()}}.ShiftRight(uint64(i % 256))
		d := U256{L: [4]uint64{rng.Uint64(), rng.Uint64(), rng.Uint64(), rng.Uint64()}}.ShiftRight(uint64((i * 73) % 256))
		check(n, d)
	}
	// Quotients adjacent to whole-word boundaries stress estimates and add-back.
	modulus := new(big.Int).Lsh(big.NewInt(1), 256)
	for i := 0; i < 10000; i++ {
		d := U256{L: [4]uint64{rng.Uint64(), rng.Uint64(), rng.Uint64(), 0}}.ShiftRight(uint64(i % 160))
		if d.IsZero() {
			d.L[0] = 1
		}
		dv := big256(d)
		q := new(big.Int).SetUint64(rng.Uint64())
		if i%3 == 0 {
			q.SetUint64(1 << 32)
		}
		n := new(big.Int).Mul(dv, q)
		if i%2 == 0 {
			n.Sub(n, big.NewInt(1))
		} else {
			n.Add(n, new(big.Int).Sub(dv, big.NewInt(1)))
		}
		if n.Sign() < 0 || n.Cmp(modulus) >= 0 {
			continue
		}
		var encoded U256
		for j := 0; j < 4; j++ {
			encoded.L[j] = new(big.Int).Rsh(new(big.Int).Set(n), uint(j*64)).Uint64()
		}
		check(encoded, d)
	}
}
