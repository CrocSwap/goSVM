package math
import("math/big"; "math/rand"; "testing")
func TestOptimizedMulDiv(t *testing.T) {
 rng:=rand.New(rand.NewSource(20261008))
 check:=func(a,b,d U128){
  t.Helper()
  for _,up:=range []bool{false,true}{
   got,code:=MulDiv(a,b,d,up)
   var old U128;var err uint64
   p:=Mul128(a,b)
   if d.IsZero(){err=DivideByZero}else if p.L[2]!=0||p.L[3]!=0{err=MulDivOverflow}else{old,err=DivRound(p,d.Wide(),up)}
   if got!=old||code!=err{t.Fatalf("a=%+v b=%+v d=%+v up=%v got=%+v/%d old=%+v/%d",a,b,d,up,got,code,old,err)}
   product:=new(big.Int).Mul(big128(a),big128(b))
   wantErr:=uint64(0);want:=new(big.Int)
   if d.IsZero(){wantErr=DivideByZero}else if product.BitLen()>128{wantErr=MulDivOverflow}else{
    rem:=new(big.Int);want.QuoRem(product,big128(d),rem)
    if up&&rem.Sign()!=0{want.Add(want,big.NewInt(1))}
    if want.BitLen()>128{wantErr=NumberDownCast}
   }
   if code!=wantErr||(code==0&&big128(got).Cmp(want)!=0){t.Fatal("math/big mismatch",a,b,d,up,got,code,want,wantErr)}
  }
 }
 edges:=[]U128{{},{Lo:1},{Lo:2},{Lo:1<<32-1},{Lo:1<<32},{Lo:^uint64(0)},{Hi:1},{Lo:^uint64(0),Hi:1},{Hi:1<<63},{Lo:^uint64(0),Hi:^uint64(0)}}
 for _,a:=range edges{for _,b:=range edges{for _,d:=range edges{check(a,b,d)}}}
 for i:=0;i<20000;i++{
  a,b,d:=U128{rng.Uint64(),rng.Uint64()},U128{rng.Uint64(),rng.Uint64()},U128{rng.Uint64(),rng.Uint64()}
  switch i%5{case 0:a.Hi=0;b.Hi=0;d.Hi=0;case 1:b=U128{Lo:uint64(i%10000)};case 2:a.Hi=0;b.Hi=0;case 3:a=U128{Lo:uint64(i%10000)};d.Hi=0}
  check(a,b,d)
 }
}
