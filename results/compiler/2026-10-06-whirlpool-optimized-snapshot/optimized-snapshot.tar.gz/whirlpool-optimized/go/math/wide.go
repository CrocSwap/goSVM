// Package math implements Orca-compatible arithmetic with unsigned limbs.
// It is shared by native Go callers and the restricted goSVM compiler.
package math

type U128 struct {
	Lo uint64
	Hi uint64
}
type U256 struct{ L [4]uint64 }

const DivideByZero uint64 = 6006
const NumberCast uint64 = 6007
const NumberDownCast uint64 = 6008
const PriceOutOfBounds uint64 = 6011
const LiquidityOverflow uint64 = 6014
const LiquidityUnderflow uint64 = 6015
const TokenMaxExceeded uint64 = 6017
const TokenMinSubceeded uint64 = 6018
const MultiplicationShiftRightOverflow uint64 = 6030
const MulDivOverflow uint64 = 6031
const MultiplicationOverflow uint64 = 6033

func (a U128) Eq(b U128) bool   { return a.Lo == b.Lo && a.Hi == b.Hi }
func (a U128) IsZero() bool     { return a.Lo == 0 && a.Hi == 0 }
func (a U128) Less(b U128) bool { return a.Hi < b.Hi || (a.Hi == b.Hi && a.Lo < b.Lo) }
func (a U128) Wide() U256       { return U256{L: [4]uint64{a.Lo, a.Hi, 0, 0}} }

func Add128(a, b U128) (U128, bool) {
	lo := a.Lo + b.Lo
	carry := uint64(0)
	if lo < a.Lo {
		carry = 1
	}
	hi := a.Hi + b.Hi
	overflow := hi < a.Hi
	next := hi + carry
	return U128{lo, next}, overflow || next < hi
}
func Sub128(a, b U128) (U128, bool) {
	borrow := uint64(0)
	if a.Lo < b.Lo {
		borrow = 1
	}
	return U128{a.Lo - b.Lo, a.Hi - b.Hi - borrow}, a.Less(b)
}
func Neg128(a U128) U128 { r, _ := Sub128(U128{}, a); return r }

// The delta is the original i128 two's-complement wire representation.
func AddLiquidity(liquidity, delta U128) (U128, uint64) {
	if delta.Hi>>63 != 0 {
		r, under := Sub128(liquidity, Neg128(delta))
		if under {
			return U128{}, LiquidityUnderflow
		}
		return r, 0
	}
	r, over := Add128(liquidity, delta)
	if over {
		return U128{}, LiquidityOverflow
	}
	return r, 0
}
func (a U256) IsZero() bool { return a.L[0] == 0 && a.L[1] == 0 && a.L[2] == 0 && a.L[3] == 0 }
func (a U256) Less(b U256) bool {
	for j := uint64(4); j > 0; j-- {
		if a.L[j-1] != b.L[j-1] {
			return a.L[j-1] < b.L[j-1]
		}
	}
	return false
}
func Add256(a, b U256) (U256, bool) {
	var r U256
	carry := uint64(0)
	for j := uint64(0); j < 4; j++ {
		x := a.L[j] + b.L[j]
		next := x + carry
		carry = 0
		if x < a.L[j] || next < x {
			carry = 1
		}
		r.L[j] = next
	}
	return r, carry != 0
}
func Sub256(a, b U256) U256 {
	var r U256
	borrow := uint64(0)
	for j := uint64(0); j < 4; j++ {
		x := a.L[j] - b.L[j]
		next := x - borrow
		borrow = 0
		if a.L[j] < b.L[j] || x < next {
			borrow = 1
		}
		r.L[j] = next
	}
	return r
}
func (a U256) ShiftLeftOne() (U256, bool) {
	return U256{L: [4]uint64{a.L[0] << 1, a.L[1]<<1 | a.L[0]>>63,
		a.L[2]<<1 | a.L[1]>>63, a.L[3]<<1 | a.L[2]>>63}}, a.L[3]>>63 != 0
}
func (a U256) ShiftLeftWord() (U256, bool) {
	return U256{L: [4]uint64{0, a.L[0], a.L[1], a.L[2]}}, a.L[3] != 0
}
func (a U256) ShiftRight(n uint64) U256 {
	var r U256
	if n >= 256 {
		return r
	}
	words := n / 64
	bits := n % 64
	for j := uint64(0); j+words < 4; j++ {
		r.L[j] = a.L[j+words] >> bits
		if bits != 0 && j+words+1 < 4 {
			r.L[j] = r.L[j] | a.L[j+words+1]<<(64-bits)
		}
	}
	return r
}
func (a U256) ShiftLeft(n uint64) U256 {
	var r U256
	if n >= 256 {
		return r
	}
	words, bits := n/64, n%64
	for j := words; j < 4; j++ {
		r.L[j] = a.L[j-words] << bits
		if bits != 0 && j > words {
			r.L[j] = r.L[j] | a.L[j-words-1]>>(64-bits)
		}
	}
	return r
}
func BitLen64(v uint64) uint64 {
	if v == 0 {
		return 0
	}
	n := uint64(1)
	if v >= 4294967296 {
		v = v >> 32
		n = n + 32
	}
	if v >= 65536 {
		v = v >> 16
		n = n + 16
	}
	if v >= 256 {
		v = v >> 8
		n = n + 8
	}
	if v >= 16 {
		v = v >> 4
		n = n + 4
	}
	if v >= 4 {
		v = v >> 2
		n = n + 2
	}
	if v >= 2 {
		n++
	}
	return n
}
func (a U256) BitLen() uint64 {
	for j := uint64(4); j > 0; j-- {
		if a.L[j-1] != 0 {
			return (j-1)*64 + BitLen64(a.L[j-1])
		}
	}
	return 0
}
func (a U256) Narrow() (U128, uint64) {
	if a.L[2] != 0 || a.L[3] != 0 {
		return U128{}, NumberDownCast
	}
	return U128{a.L[0], a.L[1]}, 0
}

// Base 2^32 schoolbook multiplication. Each accumulation fits exactly in u64.
func Mul128(a, b U128) U256 {
	x := [4]uint64{a.Lo & 4294967295, a.Lo >> 32, a.Hi & 4294967295, a.Hi >> 32}
	y := [4]uint64{b.Lo & 4294967295, b.Lo >> 32, b.Hi & 4294967295, b.Hi >> 32}
	var z [8]uint64
	for i := uint64(0); i < 4; i++ {
		carry := uint64(0)
		for j := uint64(0); j < 4; j++ {
			v := x[i]*y[j] + z[i+j] + carry
			z[i+j] = v & 4294967295
			carry = v >> 32
		}
		z[i+4] = carry
	}
	return U256{L: [4]uint64{z[0] | z[1]<<32, z[2] | z[3]<<32, z[4] | z[5]<<32, z[6] | z[7]<<32}}
}

func Div256(n, d U256) (U256, U256, uint64) {
	var q, r U256
	if d.IsZero() {
		return q, r, DivideByZero
	}
	if n.Less(d) {
		return q, n, 0
	}
	// Align the divisor first: iterate only significant quotient bits instead
	// of repeatedly shifting the leading portion of the dividend into a remainder.
	shift := n.BitLen() - d.BitLen()
	divisor := d.ShiftLeft(shift)
	r = n
	for k := shift + 1; k > 0; k-- {
		if !r.Less(divisor) {
			r = Sub256(r, divisor)
			q.L[(k-1)/64] = q.L[(k-1)/64] | uint64(1)<<((k-1)%64)
		}
		divisor = divisor.ShiftRight(1)
	}
	return q, r, 0
}
func DivRound(n, d U256, up bool) (U128, uint64) {
	q, r, code := Div256(n, d)
	if code != 0 {
		return U128{}, code
	}
	if up && !r.IsZero() {
		var over bool
		q, over = Add256(q, U128{Lo: 1}.Wide())
		if over {
			return U128{}, NumberDownCast
		}
	}
	return q.Narrow()
}
func MulDiv(a, b, d U128, up bool) (U128, uint64) {
	if d.IsZero() {
		return U128{}, DivideByZero
	}
	if a.Hi == 0 && b.Hi == 0 {
		return DivRound128(Mul64(a.Lo, b.Lo), d, up)
	}
	p := Mul128(a, b)
	if p.L[2] != 0 || p.L[3] != 0 {
		return U128{}, MulDivOverflow
	}
	return DivRound128(U128{Lo: p.L[0], Hi: p.L[1]}, d, up)
}

// Mul64 returns the exact double-word product using four base-2^32 products.
func Mul64(a, b uint64) U128 {
	const mask uint64 = 4294967295
	low := (a & mask) * (b & mask)
	middle := (a>>32)*(b&mask) + (low >> 32)
	carry := middle >> 32
	middle = (a&mask)*(b>>32) + (middle & mask)
	return U128{Lo: middle<<32 | low&mask, Hi: (a>>32)*(b>>32) + carry + (middle >> 32)}
}

// divWord divides a double word by one word, with 0 <= hi < divisor.
// Normalization makes each base-2^32 quotient estimate at most two too large.
// This is the same long-division algorithm used by Go math/bits.Div64, expressed
// in the supported unsigned subset (see THIRD_PARTY_NOTICES).
func divWord(hi, lo, divisor uint64) (uint64, uint64) {
	if hi == 0 {
		return lo / divisor, lo % divisor
	}
	shift := 64 - BitLen64(divisor)
	normalized := divisor << shift
	upper := hi<<shift | lo>>(64-shift)
	lower := lo << shift
	const base uint64 = 4294967296
	const mask uint64 = 4294967295
	highDigit := normalized >> 32
	lowDigit := normalized & mask
	first := upper / highDigit
	remainder := upper - first*highDigit
	for first >= base || first*lowDigit > remainder*base+(lower>>32) {
		first--
		remainder = remainder + highDigit
		if remainder >= base {
			break
		}
	}
	residual := upper*base + (lower >> 32) - first*normalized
	second := residual / highDigit
	remainder = residual - second*highDigit
	for second >= base || second*lowDigit > remainder*base+(lower&mask) {
		second--
		remainder = remainder + highDigit
		if remainder >= base {
			break
		}
	}
	return first*base + second, (residual*base + (lower & mask) - second*normalized) >> shift
}

// Div128 specializes the bounded next-price numerator without changing Div256.
// A two-word denominator is normalized and estimated from its highest word;
// the complete product corrects the estimate before the remainder is formed.
func Div128(n, d U128) (U128, U128, uint64) {
	if d.IsZero() {
		return U128{}, U128{}, DivideByZero
	}
	if n.Less(d) {
		return U128{}, n, 0
	}
	if d.Hi == 0 {
		high, remainder := n.Hi/d.Lo, n.Hi%d.Lo
		low, remainder := divWord(remainder, n.Lo, d.Lo)
		return U128{Lo: low, Hi: high}, U128{Lo: remainder}, 0
	}
	shift := 64 - BitLen64(d.Hi)
	divisor := d.Hi<<shift | d.Lo>>(64-shift)
	upper := n.Hi >> (64 - shift)
	lower := n.Hi<<shift | n.Lo>>(64-shift)
	estimate, _ := divWord(upper, lower, divisor)
	for {
		lowProduct := Mul64(estimate, d.Lo)
		highProduct := Mul64(estimate, d.Hi)
		middle := lowProduct.Hi + highProduct.Lo
		top := highProduct.Hi
		if middle < lowProduct.Hi {
			top++
		}
		product := U128{Lo: lowProduct.Lo, Hi: middle}
		if top == 0 && !n.Less(product) {
			remainder, _ := Sub128(n, product)
			return U128{Lo: estimate}, remainder, 0
		}
		estimate--
	}
}
func DivRound128(n, d U128, up bool) (U128, uint64) {
	q, r, code := Div128(n, d)
	if code != 0 {
		return U128{}, code
	}
	if up && !r.IsZero() {
		var overflow bool
		q, overflow = Add128(q, U128{Lo: 1})
		if overflow {
			return U128{}, NumberDownCast
		}
	}
	return q, 0
}

// Div256Words is normalized long division in base 2^32. Each iteration produces
// a complete quotient digit, with bounded estimate correction and an exact
// multiply/subtract. Digits use u64 storage so products plus carry fit natively.
// Div256 remains the independent bitwise fallback/reference for other callers.
func Div256Words(n, d U256) (U256, U256, uint64) {
	var q, remainder U256
	if d.IsZero() {
		return q, remainder, DivideByZero
	}
	if n.Less(d) {
		return q, n, 0
	}
	if n.L[2] == 0 && n.L[3] == 0 {
		a, b, code := Div128(U128{Lo: n.L[0], Hi: n.L[1]}, U128{Lo: d.L[0], Hi: d.L[1]})
		return a.Wide(), b.Wide(), code
	}
	if d.L[1] == 0 && d.L[2] == 0 && d.L[3] == 0 {
		r := uint64(0)
		for j := uint64(4); j > 0; j-- {
			q.L[j-1], r = divWord(r, n.L[j-1], d.L[0])
		}
		remainder.L[0] = r
		return q, remainder, 0
	}
	const mask uint64 = 4294967295
	const base uint64 = 4294967296
	nd := [8]uint64{n.L[0] & mask, n.L[0] >> 32, n.L[1] & mask, n.L[1] >> 32, n.L[2] & mask, n.L[2] >> 32, n.L[3] & mask, n.L[3] >> 32}
	dd := [8]uint64{d.L[0] & mask, d.L[0] >> 32, d.L[1] & mask, d.L[1] >> 32, d.L[2] & mask, d.L[2] >> 32, d.L[3] & mask, d.L[3] >> 32}
	nl, dl := uint64(8), uint64(8)
	for nd[nl-1] == 0 {
		nl--
	}
	for dd[dl-1] == 0 {
		dl--
	}
	shift := 32 - BitLen64(dd[dl-1])
	var u [9]uint64
	var v, digits [8]uint64
	carry := uint64(0)
	for i := uint64(0); i < nl; i++ {
		x := nd[i]<<shift | carry
		u[i] = x & mask
		carry = x >> 32
	}
	u[nl] = carry
	carry = 0
	for i := uint64(0); i < dl; i++ {
		x := dd[i]<<shift | carry
		v[i] = x & mask
		carry = x >> 32
	}
	for k := nl - dl + 1; k > 0; k-- {
		j := k - 1
		numerator := u[j+dl]*base + u[j+dl-1]
		estimate := numerator / v[dl-1]
		rest := numerator % v[dl-1]
		if estimate >= base {
			estimate = mask
			rest = numerator - estimate*v[dl-1]
		}
		for rest < base && estimate*v[dl-2] > rest*base+u[j+dl-2] {
			estimate--
			rest = rest + v[dl-1]
		}
		borrow := uint64(0)
		for i := uint64(0); i < dl; i++ {
			product := estimate*v[i] + borrow
			low := product & mask
			borrow = product >> 32
			if u[j+i] < low {
				borrow++
			}
			u[j+i] = (u[j+i] - low) & mask
		}
		negative := u[j+dl] < borrow
		u[j+dl] = (u[j+dl] - borrow) & mask
		if negative {
			estimate--
			carry = 0
			for i := uint64(0); i < dl; i++ {
				sum := u[j+i] + v[i] + carry
				u[j+i] = sum & mask
				carry = sum >> 32
			}
			u[j+dl] = (u[j+dl] + carry) & mask
		}
		digits[j] = estimate
	}
	q = U256{L: [4]uint64{digits[0] | digits[1]<<32, digits[2] | digits[3]<<32, digits[4] | digits[5]<<32, digits[6] | digits[7]<<32}}
	for i := uint64(0); i < dl; i++ {
		dd[i] = (u[i]>>shift | u[i+1]<<(32-shift)) & mask
	}
	for i := dl; i < 8; i++ {
		dd[i] = 0
	}
	remainder = U256{L: [4]uint64{dd[0] | dd[1]<<32, dd[2] | dd[3]<<32, dd[4] | dd[5]<<32, dd[6] | dd[7]<<32}}
	return q, remainder, 0
}
func DivRoundWords(n, d U256, up bool) (U128, uint64) {
	q, r, code := Div256Words(n, d)
	if code != 0 {
		return U128{}, code
	}
	if up && !r.IsZero() {
		var overflow bool
		q, overflow = Add256(q, U128{Lo: 1}.Wide())
		if overflow {
			return U128{}, NumberDownCast
		}
	}
	return q.Narrow()
}
