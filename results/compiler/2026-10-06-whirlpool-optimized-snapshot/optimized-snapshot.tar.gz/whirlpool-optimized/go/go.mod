module example.org/gosvm-benchmarks/whirlpool

go 1.22

require gosvm v0.0.0

replace gosvm => ./.gosvm/sdk
