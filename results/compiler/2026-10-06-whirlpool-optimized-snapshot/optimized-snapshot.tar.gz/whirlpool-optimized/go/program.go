// Package program exposes the shared swap step through schema-2 bindings.
// This math test program is distinct from the exact-layout swap-core probe.
package program

import (
	"example.org/gosvm-benchmarks/whirlpool/math"
	"example.org/gosvm-benchmarks/whirlpool/model"
	"gosvm/solana"
)

func Step(c solana.Context, a StepAccounts, args model.StepArgs) (StepAccounts, uint64) {
	if args.Input > 1 || args.AToB > 1 {
		return a, 7100
	}
	result, code := math.ComputeSwap(args.Amount, args.FeeRate, args.Liquidity, args.Current, args.Target, args.Input == 1, args.AToB == 1)
	if code != 0 {
		return a, code
	}
	a.Output = model.StepOutput{AmountIn: result.AmountIn, AmountOut: result.AmountOut, NextPrice: result.NextPrice, Fee: result.Fee}
	return a, 0
}
