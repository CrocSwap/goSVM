// Package model contains canonical types shared with generated clients.
package model

import "example.org/gosvm-benchmarks/whirlpool/math"

type StepArgs struct {
	Amount    uint64
	FeeRate   uint32
	Liquidity math.U128
	Current   math.U128
	Target    math.U128
	Input     byte
	AToB      byte
}
type StepOutput struct {
	AmountIn  uint64
	AmountOut uint64
	NextPrice math.U128
	Fee       uint64
}
