package program_test

import (
	"bytes"
	"encoding/binary"
	program "example.org/gosvm-benchmarks/whirlpool"
	"example.org/gosvm-benchmarks/whirlpool/client"
	"example.org/gosvm-benchmarks/whirlpool/math"
	"example.org/gosvm-benchmarks/whirlpool/model"
	"gosvm/solana"
	"testing"
)

func TestGeneratedSharedStep(t *testing.T) {
	args := model.StepArgs{Amount: 100, FeeRate: 3000, Liquidity: math.U128{Lo: 1000000}, Current: math.U128{Hi: 1}, Target: math.U128{Lo: 18445821805675392311}, Input: 1, AToB: 1}
	want, code := math.ComputeSwap(args.Amount, args.FeeRate, args.Liquidity, args.Current, args.Target, true, true)
	if code != 0 {
		t.Fatal(code)
	}
	id := bytes.Repeat([]byte{9}, 32)
	c := solana.Context{ID: id, InstructionData: client.EncodeInstructionStep(args), Accounts: []solana.Account{
		{Key: bytes.Repeat([]byte{10}, 32), Owner: id, Writable: true, Data: client.EncodeAccountStepOutput(model.StepOutput{})},
	}}
	if code = program.Process(c); code != 0 {
		t.Fatal(code)
	}
	output, err := client.DecodeAccountStepOutput(c.Accounts[0].Data)
	if err != nil || output.AmountIn != want.AmountIn || output.AmountOut != want.AmountOut || output.NextPrice != want.NextPrice || output.Fee != want.Fee {
		t.Fatal(output, err)
	}
	// Independently check packed offsets and the full-width limbs on the wire.
	if binary.LittleEndian.Uint64(c.Accounts[0].Data[24:]) != want.NextPrice.Lo || binary.LittleEndian.Uint64(c.Accounts[0].Data[32:]) != want.NextPrice.Hi {
		t.Fatal("wide state wire offsets")
	}
	before := append([]byte(nil), c.Accounts[0].Data...)
	args.Input = 2
	c.InstructionData = client.EncodeInstructionStep(args)
	if code = program.Process(c); code != 7100 || !bytes.Equal(c.Accounts[0].Data, before) {
		t.Fatal("invalid boolean committed state", code)
	}
}
