# Experimental optimized Whirlpools snapshot

The matched default-O2 classic-token fixed-fee handler (events omitted) measures
1.280853x scoped Rust, median paired successful-case CU. All 166 scenarios pass
three runs against Go, unchanged scoped Rust and full upstream Rust. Expanded
29,713-case SBF arithmetic probes pass three runs in Go and unchanged Rust.
Individual successful ratios range from 1.226617x to 1.617088x.

Both Go modules include their exact matching SDK. The macOS arm64 CLI is
executable. frontend.tar.gz contains its previously verified complete frontend
source/SDK snapshot. Solana platform-tools v1.51 LLVM is required separately.

From this directory, rebuild the exact default-O2 artifact:

    ./gosvm -no-cache -llvm /absolute/path/to/platform-tools/llvm -o rebuilt.so ./handler

The expected ELF SHA256 is recorded in manifest.json. Record a new complete
application/frontend/SDK pin before benchmark adoption. Original benchmark
defaults remain unchanged. Native Go tests live in the separate go module.
On the tested Go 1.22/macOS host, use an explicit writable GOCACHE and
go test -ldflags=-linkmode=external ./... in that module.

The private applyValidated core is called only by checked Apply and the fully
validating ProcessHandler in the same package. Keep exact-buffer/key validation
and the interval without writes or CPIs intact. Public Apply still validates
independent callers, including buffers changed after earlier validation.

This scoped experiment does not add events, adaptive fees or dynamic arrays.
See the linked project proof/report for fixture/runtime pins and per-case CU.
