# Compact signer experiment

This module is a separate fixed-fee handler experiment. The production module,
`tools/handler-clock-v1/` and its SDK remain unchanged. Shared application math
and tick validation are identical to the fee-growth checkpoint.

`tools/handler-compact-signer-v1/` archives the complete derived frontend source
and records its parent lock. Only `sdk/cpi/cpi.go` differs from the parent: it
adds `SingleSigner` and `InvokeSingle`. Compiler, generator, runtime boundary,
existing PDA/general signer APIs and all other SDK files are unchanged. The
module's SDK was scaffolded with that derived CLI using `-schema 2 -sdk 2`.

The handler writes six Whirlpool seeds directly into the final one-group
encoding instead of copying `Seeds.Bytes()` into a general `Signers` buffer.
The compact builder has a 530-byte buffer, supports all 16 seeds of up to 32
bytes, and retains the original seed error/capacity checks. It represents one
group; the unchanged general API still supports two groups and 1,024 bytes.
`Bytes` borrows the builder, which must remain alive/unmodified through invoke.

The native test compares 10,000 addition sequences to the existing builder,
including rejected additions and exact bytes, plus maximum capacity. The compact
SBF probe independently checks six-seed, empty, scalar and full-530-byte output,
seed errors, rollback and nil metadata. The existing 20-case general SDK probe
also runs against this snapshot.

```sh
python3 scripts/restore_gosvm.py --pin tools/handler-compact-signer-v1
python3 scripts/verify_compact_signer.py --output results/whirlpool/my-compact-run
python3 scripts/measure_stack.py --pin tools/handler-compact-signer-v1 \
  --package programs/whirlpool/go-handler-compact-v1 \
  --elf build/verification/my-compact-run/handler.so \
  --output results/whirlpool/my-compact-stack
```

Like the existing diagnostic tools, verification uses the preserved baseline's
runner, transaction maker, fixture and Rust ELFs under
`build/verification/2026-10-06-fee-growth-handler/`. The general-probe fixture
is under `build/sdk-isolation/2026-10-06-sdk-isolation/`. Recreate those with
the baseline verification and SDK isolation scripts if absent. Every run uses
a new result directory and replays 166 cases three times for prototype, SDK-only
control, baseline, scoped Rust and full Rust. The SDK-only control must be
reviewed for exact equality before attributing improvements to the prototype.

[Results and limits](../../../docs/COMPACT_SIGNER.md) include per-case CU,
ELF and static frames. This experiment is not promoted to the production module
or the default Makefile pin.
