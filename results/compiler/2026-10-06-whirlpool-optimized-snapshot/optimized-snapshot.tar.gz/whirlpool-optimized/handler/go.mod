module example.org/gosvm-benchmarks/whirlpool-handler

go 1.22

require (
 gosvm v0.0.0
 example.org/gosvm-benchmarks/whirlpool v0.0.0
)

replace gosvm => ./.gosvm/sdk
replace example.org/gosvm-benchmarks/whirlpool => ../go
