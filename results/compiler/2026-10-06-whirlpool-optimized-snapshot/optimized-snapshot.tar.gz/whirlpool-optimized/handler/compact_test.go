package handler

import (
	"bytes"
	"gosvm/sdk/cpi"
	"gosvm/sdk/pda"
	"math/rand"
	"testing"
)

func TestCompactMatchesGeneralEncoding(t *testing.T) {
	rng := rand.New(rand.NewSource(20261006))
	for trial := 0; trial < 10000; trial++ {
		var seeds pda.Seeds
		var compact cpi.SingleSigner
		// Include empty groups, max groups, empty seeds and rejected additions.
		n := trial % 21
		for i := 0; i < n; i++ {
			b := make([]byte, rng.Intn(35))
			rng.Read(b)
			if a, bcode := seeds.AddBytes(b), compact.AddBytes(b); a != bcode {
				t.Fatalf("trial %d addition %d: %d != %d", trial, i, a, bcode)
			}
		}
		var general cpi.Signers
		if general.Add(&seeds) != 0 || !bytes.Equal(general.Bytes(), compact.Bytes()) {
			t.Fatalf("trial %d: encoding mismatch", trial)
		}
	}
	var old pda.Seeds
	var compact cpi.SingleSigner
	for i := 0; i < 16; i++ {
		b := bytes.Repeat([]byte{byte(i)}, 32)
		if old.AddBytes(b) != 0 || compact.AddBytes(b) != 0 {
			t.Fatal("max seed rejected")
		}
	}
	var general cpi.Signers
	if general.Add(&old) != 0 || len(compact.Bytes()) != 530 || !bytes.Equal(general.Bytes(), compact.Bytes()) {
		t.Fatal("maximum encoding")
	}
	before := append([]byte(nil), compact.Bytes()...)
	if old.AddByte(7) != pda.ErrSeeds || compact.AddByte(7) != pda.ErrSeeds || !bytes.Equal(before, compact.Bytes()) {
		t.Fatal("failed append mutated encoding")
	}
}
