// Package probe checks compact signer bytes and seed errors in actual SBF.
package probe

import (
	"gosvm/sdk/cpi"
	"gosvm/solana"
)

func Process(c solana.Context) uint64 {
	d := solana.Instruction(c)
	if len(d) != 1 || solana.Count(c) != 2 || !solana.Writable(c, 0) {
		return 7310
	}
	out, pool := solana.Data(c, 0), solana.Data(c, 1)
	if len(out) != 530 || len(pool) != 653 {
		return 7310
	}
	var signer cpi.SingleSigner
	if d[0] == 0 {
		return 0
	}
	if d[0] == 1 {
		var prefix [9]byte
		prefix[0] = 119
		prefix[1] = 104
		prefix[2] = 105
		prefix[3] = 114
		prefix[4] = 108
		prefix[5] = 112
		prefix[6] = 111
		prefix[7] = 111
		prefix[8] = 108
		signer.AddBytes(prefix[:])
		signer.AddBytes(pool[8:40])
		signer.AddBytes(pool[101:133])
		signer.AddBytes(pool[181:213])
		signer.AddBytes(pool[43:45])
		signer.AddByte(pool[40])
	} else if d[0] == 2 || d[0] == 5 {
		for i := uint64(0); i < 16; i++ {
			if signer.AddBytes(pool[:32]) != 0 {
				return 7311
			}
		}
		if d[0] == 5 {
			return signer.AddByte(7)
		}
	} else if d[0] == 3 {
		return signer.AddBytes(pool[:33])
	} else if d[0] == 4 {
		for i := uint64(0); i < 16; i++ {
			if signer.AddBytes(pool[:0]) != 0 {
				return 7311
			}
		}
		return signer.AddBytes(pool[:0])
	} else if d[0] == 6 {
		signer.AddByte(255)
	} else if d[0] == 8 {
		return cpi.InvokeSingle(c, 0, nil, nil, &signer)
	} else if d[0] != 7 {
		return 7310
	}
	b := signer.Bytes()
	for i := uint64(0); i < uint64(len(b)); i++ {
		out[i] = b[i]
	}
	return 0
}
