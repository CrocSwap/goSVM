package handler
import("gosvm/solana";"example.org/gosvm-benchmarks/whirlpool/swap")
func Process(c solana.Context)uint64{return swap.ProcessHandler(c)}
