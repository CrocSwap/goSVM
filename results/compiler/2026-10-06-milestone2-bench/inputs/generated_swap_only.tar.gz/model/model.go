// Package model defines the canonical swap types shared with ordinary Go services.
package model

type PublicKey [32]byte
type Pool struct {
	VaultX PublicKey
	VaultY PublicKey
	MintX  PublicKey
	MintY  PublicKey
	Bump   byte
	Swaps  uint64
}
type SwapArgs struct {
	AmountIn uint64
	MinOut   uint64
}
